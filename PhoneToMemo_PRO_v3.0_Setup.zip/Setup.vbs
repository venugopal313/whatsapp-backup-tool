' PhoneToMemo PRO v3.0 - Setup Launcher
' Double-click this file to install.
Set WshShell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")

' Get folder where this VBS lives
scriptDir = fso.GetParentFolderName(WScript.ScriptFullName)
ps1File   = scriptDir & "\Install_PhoneToMemo_PRO.ps1"

If Not fso.FileExists(ps1File) Then
    MsgBox "Error: Install_PhoneToMemo_PRO.ps1 not found." & vbCrLf & _
           "Make sure both files are in the same folder.", _
           vbCritical, "PhoneToMemo PRO Setup"
    WScript.Quit 1
End If

' Ask user to confirm
ans = MsgBox("Welcome to PhoneToMemo PRO v3.0 Setup!" & vbCrLf & vbCrLf & _
             "This will install PhoneToMemo PRO on your PC." & vbCrLf & _
             "A desktop shortcut will be created." & vbCrLf & vbCrLf & _
             "Click OK to continue.", _
             vbOKCancel + vbInformation, "PhoneToMemo PRO Setup")

If ans <> vbOK Then
    WScript.Quit 0
End If

' Run PowerShell installer in a visible window
cmd = "powershell.exe -NoProfile -ExecutionPolicy Bypass -File """ & ps1File & """"
WshShell.Run cmd, 1, True

MsgBox "Setup finished! Look for 'PhoneToMemo PRO' on your Desktop.", _
       vbInformation, "PhoneToMemo PRO"
