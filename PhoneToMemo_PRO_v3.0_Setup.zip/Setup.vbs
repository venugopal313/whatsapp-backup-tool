' PhoneToMemo PRO v3.0 - Setup Launcher
Set fso = CreateObject("Scripting.FileSystemObject")
Set WshShell = CreateObject("WScript.Shell")

scriptDir = fso.GetParentFolderName(WScript.ScriptFullName)
ps1File   = scriptDir & "\Install_PhoneToMemo_PRO.ps1"
appFile   = scriptDir & "\phonetomemo.py"
icoFile   = scriptDir & "\icon.ico"

If Not fso.FileExists(ps1File) Then
    MsgBox "Error: Install_PhoneToMemo_PRO.ps1 not found." & vbCrLf & _
           "Make sure all files are in the same folder.", vbCritical, "Setup Error"
    WScript.Quit 1
End If
If Not fso.FileExists(appFile) Then
    MsgBox "Error: phonetomemo.py not found." & vbCrLf & _
           "Make sure all files are in the same folder.", vbCritical, "Setup Error"
    WScript.Quit 1
End If

ans = MsgBox("PhoneToMemo PRO v3.0 Setup" & vbCrLf & vbCrLf & _
    "This will install PhoneToMemo PRO on your PC." & vbCrLf & vbCrLf & _
    "What gets installed:" & vbCrLf & _
    "  - PhoneToMemo PRO app" & vbCrLf & _
    "  - ADB (auto-downloaded)" & vbCrLf & _
    "  - Desktop shortcut" & vbCrLf & _
    "  - Start Menu entry" & vbCrLf & vbCrLf & _
    "Click OK to continue.", vbOKCancel + vbInformation, "PhoneToMemo PRO Setup")

If ans <> vbOK Then WScript.Quit 0

cmd = "powershell.exe -NoProfile -ExecutionPolicy Bypass -File """ & ps1File & """ """ & scriptDir & """"
WshShell.Run cmd, 1, True

desktopLnk = WshShell.SpecialFolders("Desktop") & "\PhoneToMemo PRO.lnk"
If fso.FileExists(desktopLnk) Then
    MsgBox "Installation complete!" & vbCrLf & vbCrLf & _
           "Desktop shortcut 'PhoneToMemo PRO' created." & vbCrLf & _
           "Double-click it to launch the app.", vbInformation, "Done"
Else
    MsgBox "Installation finished." & vbCrLf & vbCrLf & _
           "Check your Desktop for 'PhoneToMemo PRO'.", vbInformation, "Done"
End If
