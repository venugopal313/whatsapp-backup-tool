' PhoneToMemo PRO v3.0 - Setup Launcher
' Double-click this file to install
Set fso = CreateObject("Scripting.FileSystemObject")
Set WshShell = CreateObject("WScript.Shell")

scriptDir = fso.GetParentFolderName(WScript.ScriptFullName)
ps1File   = scriptDir & "\Install_PhoneToMemo_PRO.ps1"

If Not fso.FileExists(ps1File) Then
    MsgBox "Error: Install_PhoneToMemo_PRO.ps1 not found in same folder." & vbCrLf & _
           "Make sure both files are in the same folder.", vbCritical, "Setup Error"
    WScript.Quit 1
End If

ans = MsgBox("PhoneToMemo PRO v3.0 Setup" & vbCrLf & vbCrLf & _
    "This will install PhoneToMemo PRO on your PC." & vbCrLf & vbCrLf & _
    "What gets installed:" & vbCrLf & _
    "  - PhoneToMemo PRO app" & vbCrLf & _
    "  - Desktop shortcut" & vbCrLf & _
    "  - Start Menu entry" & vbCrLf & vbCrLf & _
    "Click OK to continue.", vbOKCancel + vbInformation, "PhoneToMemo PRO Setup")

If ans <> vbOK Then WScript.Quit 0

' Run PowerShell installer with visible window
cmd = "powershell.exe -NoProfile -ExecutionPolicy Bypass -File """ & ps1File & """"
WshShell.Run cmd, 1, True

' Check if desktop shortcut was created
desktopLnk = WshShell.SpecialFolders("Desktop") & "\PhoneToMemo PRO.lnk"
If fso.FileExists(desktopLnk) Then
    MsgBox "Installation complete!" & vbCrLf & vbCrLf & _
           "Desktop shortcut 'PhoneToMemo PRO' has been created." & vbCrLf & _
           "Double-click it to launch the app.", vbInformation, "Done"
Else
    MsgBox "Installation finished." & vbCrLf & vbCrLf & _
           "Check your Desktop for 'PhoneToMemo PRO' shortcut." & vbCrLf & _
           "If not found, look in: " & vbCrLf & _
           WshShell.ExpandEnvironmentStrings("%LOCALAPPDATA%") & "\PhoneToMemo", _
           vbInformation, "Done"
End If
