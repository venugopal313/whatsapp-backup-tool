# PhoneToMemo PRO v3.0 - Installer
# Usage: powershell -ExecutionPolicy Bypass -File Install_PhoneToMemo_PRO.ps1 "<SourceDir>"
param([string]$SourceDir = "")

$ErrorActionPreference = "Stop"

function Write-Header {
    Clear-Host
    Write-Host ""
    Write-Host "  ============================================" -ForegroundColor Cyan
    Write-Host "    PhoneToMemo PRO v3.0  -  Installer"       -ForegroundColor Cyan
    Write-Host "    WhatsApp ADB Transfer Tool"                -ForegroundColor Cyan
    Write-Host "  ============================================" -ForegroundColor Cyan
    Write-Host ""
}
Write-Header

# ── Resolve source dir (where Setup.vbs and files live) ──────
if (-not $SourceDir -or -not (Test-Path $SourceDir)) {
    $SourceDir = Split-Path -Parent $MyInvocation.MyCommand.Path
}
$AppPySrc  = Join-Path $SourceDir "phonetomemo.py"
$IconSrc   = Join-Path $SourceDir "icon.ico"

if (-not (Test-Path $AppPySrc)) {
    Write-Host "  ERROR: phonetomemo.py not found in $SourceDir" -ForegroundColor Red
    Read-Host "  Press Enter to exit"
    exit 1
}

# ── Install paths ─────────────────────────────────────────────
$InstallDir   = Join-Path $env:LOCALAPPDATA "PhoneToMemo"
$AdbDir       = Join-Path $InstallDir "adb"
$AppPy        = Join-Path $InstallDir "phonetomemo.py"
$IconFile     = Join-Path $InstallDir "icon.ico"
$DesktopLnk   = Join-Path ([Environment]::GetFolderPath("Desktop")) "PhoneToMemo PRO.lnk"
$StartMenuDir = Join-Path $env:APPDATA "Microsoft\Windows\Start Menu\Programs\PhoneToMemo PRO"
$UninstScript = Join-Path $InstallDir "uninstall.ps1"

Write-Host "  Installing to : $InstallDir" -ForegroundColor Yellow
Write-Host ""

# ── Step 1: Check Python ──────────────────────────────────────
Write-Host "  [1/5] Checking Python..." -ForegroundColor Yellow
$pythonExe = $null
foreach ($cmd in @("python","python3","py")) {
    try {
        $ver = & $cmd --version 2>&1
        if ($ver -match "Python 3\.([89]|1[0-9])") {
            $pythonExe = (Get-Command $cmd -ErrorAction SilentlyContinue).Source
            if (-not $pythonExe) { $pythonExe = $cmd }
            Write-Host "  OK: $ver" -ForegroundColor Green
            break
        }
    } catch {}
}

if (-not $pythonExe) {
    Write-Host "  Python 3.8+ not found. Downloading Python 3.11..." -ForegroundColor Yellow
    $pyUrl = "https://www.python.org/ftp/python/3.11.9/python-3.11.9-amd64.exe"
    $pyTmp = Join-Path $env:TEMP "python_installer.exe"
    Write-Host "  Downloading (~25 MB)..." -ForegroundColor Cyan
    (New-Object System.Net.WebClient).DownloadFile($pyUrl, $pyTmp)
    Write-Host "  Installing Python silently..." -ForegroundColor Cyan
    Start-Process -FilePath $pyTmp -ArgumentList "/quiet InstallAllUsers=0 PrependPath=1 Include_pip=1 Include_tcltk=1" -Wait
    Remove-Item $pyTmp -Force -ErrorAction SilentlyContinue
    $env:PATH = [Environment]::GetEnvironmentVariable("PATH","User") + ";" + [Environment]::GetEnvironmentVariable("PATH","Machine")
    $pythonExe = "python"
    Write-Host "  OK: Python 3.11 installed" -ForegroundColor Green
}

$pythonwExe = $pythonExe -replace "python\.exe$","pythonw.exe"
if (-not (Test-Path $pythonwExe)) { $pythonwExe = $pythonExe }

# ── Step 2: Install psutil ────────────────────────────────────
Write-Host ""
Write-Host "  [2/5] Installing dependencies..." -ForegroundColor Yellow
try {
    & $pythonExe -m pip install psutil --quiet --disable-pip-version-check 2>&1 | Out-Null
    Write-Host "  OK: psutil ready" -ForegroundColor Green
} catch {
    Write-Host "  WARN: psutil skipped (optional)" -ForegroundColor Yellow
}

# ── Step 3: Download ADB ──────────────────────────────────────
Write-Host ""
Write-Host "  [3/5] Installing ADB..." -ForegroundColor Yellow
New-Item -ItemType Directory -Force -Path $AdbDir | Out-Null

$adbExe   = Join-Path $AdbDir "adb.exe"
$adbFound = $false

$sysAdb = Get-Command adb -ErrorAction SilentlyContinue
if ($sysAdb) {
    $adbFolder = Split-Path $sysAdb.Source
    foreach ($f in @("adb.exe","AdbWinApi.dll","AdbWinUsbApi.dll")) {
        $s = Join-Path $adbFolder $f
        if (Test-Path $s) { Copy-Item $s $AdbDir -Force }
    }
    if (Test-Path $adbExe) {
        $adbFound = $true
        Write-Host "  OK: ADB copied from system" -ForegroundColor Green
    }
}

if (-not $adbFound) {
    try {
        Write-Host "  Downloading ADB (~10 MB)..." -ForegroundColor Cyan
        $adbZip     = Join-Path $env:TEMP "platform-tools.zip"
        $adbExtract = Join-Path $env:TEMP "ptm-adb-extract"
        (New-Object System.Net.WebClient).DownloadFile(
            "https://dl.google.com/android/repository/platform-tools-latest-windows.zip",
            $adbZip)
        if (Test-Path $adbExtract) { Remove-Item $adbExtract -Recurse -Force }
        Add-Type -AssemblyName System.IO.Compression.FileSystem
        [IO.Compression.ZipFile]::ExtractToDirectory($adbZip, $adbExtract)
        $ptDir = Join-Path $adbExtract "platform-tools"
        foreach ($f in @("adb.exe","AdbWinApi.dll","AdbWinUsbApi.dll")) {
            $s = Join-Path $ptDir $f
            if (Test-Path $s) { Copy-Item $s $AdbDir -Force }
        }
        Remove-Item $adbZip     -Force -ErrorAction SilentlyContinue
        Remove-Item $adbExtract -Recurse -Force -ErrorAction SilentlyContinue
        Write-Host "  OK: ADB installed" -ForegroundColor Green
        $adbFound = $true
    } catch {
        Write-Host "  WARN: Could not download ADB. Install manually." -ForegroundColor Yellow
    }
}

$userPath = [Environment]::GetEnvironmentVariable("PATH","User")
if ($userPath -notlike "*$AdbDir*") {
    [Environment]::SetEnvironmentVariable("PATH","$AdbDir;$userPath","User")
    $env:PATH = "$AdbDir;" + $env:PATH
    Write-Host "  OK: ADB added to PATH" -ForegroundColor Green
}

# ── Step 4: Copy app files ────────────────────────────────────
Write-Host ""
Write-Host "  [4/5] Installing app files..." -ForegroundColor Yellow
New-Item -ItemType Directory -Force -Path $InstallDir | Out-Null

Copy-Item $AppPySrc $AppPy -Force
Write-Host "  OK: App installed" -ForegroundColor Green

if (Test-Path $IconSrc) {
    Copy-Item $IconSrc $IconFile -Force
    Write-Host "  OK: Icon installed" -ForegroundColor Green
} else {
    $IconFile = ""
}

# ── Step 5: Create shortcuts ──────────────────────────────────
Write-Host ""
Write-Host "  [5/5] Creating shortcuts..." -ForegroundColor Yellow

try {
    $shell = New-Object -ComObject WScript.Shell

    $lnk = $shell.CreateShortcut($DesktopLnk)
    $lnk.TargetPath       = $pythonwExe
    $lnk.Arguments        = "`"$AppPy`""
    $lnk.WorkingDirectory = $InstallDir
    $lnk.Description      = "PhoneToMemo PRO - WhatsApp ADB Transfer Tool"
    if ($IconFile) { $lnk.IconLocation = "$IconFile,0" }
    $lnk.WindowStyle = 1
    $lnk.Save()
    Write-Host "  OK: Desktop shortcut created" -ForegroundColor Green

    New-Item -ItemType Directory -Force -Path $StartMenuDir | Out-Null
    $smLnk = $shell.CreateShortcut("$StartMenuDir\PhoneToMemo PRO.lnk")
    $smLnk.TargetPath       = $pythonwExe
    $smLnk.Arguments        = "`"$AppPy`""
    $smLnk.WorkingDirectory = $InstallDir
    if ($IconFile) { $smLnk.IconLocation = "$IconFile,0" }
    $smLnk.Save()
    Write-Host "  OK: Start Menu shortcut created" -ForegroundColor Green
} catch {
    Write-Host "  WARN: $_" -ForegroundColor Yellow
    $batDesk = Join-Path ([Environment]::GetFolderPath("Desktop")) "PhoneToMemo PRO.bat"
    "@echo off`r`nstart `"`" `"$pythonwExe`" `"$AppPy`"" | Out-File $batDesk -Encoding ASCII
    Write-Host "  OK: Fallback launcher on Desktop" -ForegroundColor Green
}

# ── Uninstaller ───────────────────────────────────────────────
$uninstContent = @"
Remove-Item '$InstallDir' -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item '$DesktopLnk' -Force -ErrorAction SilentlyContinue
Remove-Item '$StartMenuDir' -Recurse -Force -ErrorAction SilentlyContinue
`$p=[Environment]::GetEnvironmentVariable('PATH','User')
[Environment]::SetEnvironmentVariable('PATH',(`$p -replace [regex]::Escape('$AdbDir;'),''),'User')
Remove-Item 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\PhoneToMemo' -Recurse -Force -ErrorAction SilentlyContinue
Write-Host 'PhoneToMemo PRO uninstalled.' -ForegroundColor Green
Start-Sleep 2
"@
[IO.File]::WriteAllText($UninstScript, $uninstContent, [Text.Encoding]::UTF8)

# ── Registry ──────────────────────────────────────────────────
try {
    $reg = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\PhoneToMemo"
    New-Item -Path $reg -Force | Out-Null
    Set-ItemProperty $reg "DisplayName"     "PhoneToMemo PRO"
    Set-ItemProperty $reg "DisplayVersion"  "3.0"
    Set-ItemProperty $reg "Publisher"       "PhoneToMemo"
    Set-ItemProperty $reg "InstallLocation" $InstallDir
    if ($IconFile) { Set-ItemProperty $reg "DisplayIcon" $IconFile }
    Set-ItemProperty $reg "UninstallString" "powershell -ExecutionPolicy Bypass -File `"$UninstScript`""
    Set-ItemProperty $reg "NoModify" 1 -Type DWord
    Set-ItemProperty $reg "NoRepair" 1 -Type DWord
    Write-Host "  OK: Registered in Apps and Features" -ForegroundColor Green
} catch {}

# ── Done ──────────────────────────────────────────────────────
Write-Host ""
Write-Host "  ============================================" -ForegroundColor Green
Write-Host "   INSTALLATION COMPLETE!"                      -ForegroundColor Green
Write-Host "  ============================================" -ForegroundColor Green
Write-Host ""
Write-Host "  App      : $AppPy"      -ForegroundColor White
Write-Host "  ADB      : $AdbDir"     -ForegroundColor White
Write-Host "  Desktop  : PhoneToMemo PRO" -ForegroundColor White
Write-Host ""
Write-Host "  Before using:" -ForegroundColor Yellow
Write-Host "  1. Enable USB Debugging on phone" -ForegroundColor White
Write-Host "  2. Connect phone via USB" -ForegroundColor White
Write-Host "  3. Open MEmu emulator" -ForegroundColor White
Write-Host ""

$ans = Read-Host "  Launch PhoneToMemo PRO now? (Y/N)"
if ($ans -match "^[Yy]") {
    Start-Process $pythonwExe -ArgumentList "`"$AppPy`""
    Write-Host "  Launching..." -ForegroundColor Green
}
Write-Host ""
Write-Host "  Press Enter to close..."
Read-Host
