"""
DataBridge PRO v3.0 - Installer
Double-click this file to install. Python must be installed.
"""
import os, sys, shutil, subprocess, winreg, ctypes
from pathlib import Path

# ── Paths ─────────────────────────────────────────────────────
SCRIPT_DIR  = Path(__file__).parent.resolve()
APP_SRC     = SCRIPT_DIR / "databridge.py"
ICON_SRC    = SCRIPT_DIR / "icon.ico"
INSTALL_DIR = Path(os.environ["LOCALAPPDATA"]) / "DataBridge"
ADB_DIR     = INSTALL_DIR / "adb"
APP_DST     = INSTALL_DIR / "databridge.py"
ICON_DST    = INSTALL_DIR / "icon.ico"
DESKTOP     = Path(os.environ["USERPROFILE"]) / "Desktop"
START_MENU  = Path(os.environ["APPDATA"]) / "Microsoft/Windows/Start Menu/Programs/DataBridge PRO"

def log(msg, color=None):
    colors = {"green":"\033[92m","yellow":"\033[93m","red":"\033[91m","cyan":"\033[96m","bold":"\033[1m"}
    reset = "\033[0m"
    prefix = colors.get(color,"")
    print(f"  {prefix}{msg}{reset}")

def check_py():
    v = sys.version_info
    log(f"Python {v.major}.{v.minor}.{v.micro} detected", "green")
    return sys.executable

def install_psutil(py):
    try:
        subprocess.run([py,"-m","pip","install","psutil",
                        "--quiet","--disable-pip-version-check"],
                       check=True, capture_output=True)
        log("psutil installed", "green")
    except:
        log("psutil skipped (optional)", "yellow")

def download_adb():
    ADB_DIR.mkdir(parents=True, exist_ok=True)
    adb_exe = ADB_DIR / "adb.exe"
    # Check system ADB first
    sys_adb = shutil.which("adb")
    if sys_adb:
        adb_dir = Path(sys_adb).parent
        for f in ["adb.exe","AdbWinApi.dll","AdbWinUsbApi.dll"]:
            src = adb_dir / f
            if src.exists():
                shutil.copy2(src, ADB_DIR / f)
        if adb_exe.exists():
            log("ADB copied from system", "green")
            return True
    # Download from Google
    try:
        import urllib.request, zipfile, tempfile
        log("Downloading ADB (~10 MB)...", "cyan")
        url = "https://dl.google.com/android/repository/platform-tools-latest-windows.zip"
        tmp_zip = Path(tempfile.gettempdir()) / "platform-tools.zip"
        urllib.request.urlretrieve(url, tmp_zip,
            reporthook=lambda b,bs,ts: print(f"\r  {min(100,int(b*bs/ts*100))}%...",end="",flush=True))
        print()
        tmp_dir = Path(tempfile.gettempdir()) / "ptm_adb_extract"
        if tmp_dir.exists(): shutil.rmtree(tmp_dir)
        with zipfile.ZipFile(tmp_zip, 'r') as z:
            z.extractall(tmp_dir)
        pt = tmp_dir / "platform-tools"
        for f in ["adb.exe","AdbWinApi.dll","AdbWinUsbApi.dll"]:
            src = pt / f
            if src.exists(): shutil.copy2(src, ADB_DIR / f)
        tmp_zip.unlink(missing_ok=True)
        shutil.rmtree(tmp_dir, ignore_errors=True)
        log("ADB downloaded and installed", "green")
        return True
    except Exception as e:
        log(f"ADB download failed: {e}", "yellow")
        log("You can install ADB manually later", "yellow")
        return False

def add_to_path(new_dir):
    try:
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER,
                             "Environment", 0, winreg.KEY_ALL_ACCESS)
        try:
            cur, _ = winreg.QueryValueEx(key, "PATH")
        except FileNotFoundError:
            cur = ""
        if str(new_dir) not in cur:
            winreg.SetValueEx(key, "PATH", 0, winreg.REG_EXPAND_SZ,
                              f"{new_dir};{cur}")
            log(f"ADB added to PATH", "green")
        winreg.CloseKey(key)
    except Exception as e:
        log(f"PATH update skipped: {e}", "yellow")

def copy_app():
    INSTALL_DIR.mkdir(parents=True, exist_ok=True)
    shutil.copy2(APP_SRC, APP_DST)
    log(f"App installed → {APP_DST}", "green")
    if ICON_SRC.exists():
        shutil.copy2(ICON_SRC, ICON_DST)
        log("Icon installed", "green")

def create_shortcut(py_exe):
    """Create .lnk shortcut using Windows Script Host COM via subprocess."""
    pythonw = Path(py_exe).parent / "pythonw.exe"
    if not pythonw.exists(): pythonw = Path(py_exe)
    icon_line = f'oLink.IconLocation = "{ICON_DST},0"' if ICON_DST.exists() else ""

    def _make_vbs(lnk_path, target, args, workdir):
        return f"""Set oWS = WScript.CreateObject("WScript.Shell")
Set oLink = oWS.CreateShortcut("{lnk_path}")
oLink.TargetPath = "{target}"
oLink.Arguments = "{args}"
oLink.WorkingDirectory = "{workdir}"
oLink.Description = "DataBridge PRO"
{icon_line}
oLink.Save
"""

    success = True
    for label, lnk_path in [
        ("Desktop", str(DESKTOP / "DataBridge PRO.lnk")),
        ("Start Menu", str(START_MENU / "DataBridge PRO.lnk")),
    ]:
        try:
            if label == "Start Menu":
                START_MENU.mkdir(parents=True, exist_ok=True)
            vbs_content = _make_vbs(
                lnk_path.replace("\\", "\\\\"),
                str(pythonw).replace("\\", "\\\\"),
                str(APP_DST).replace("\\", "\\\\"),
                str(INSTALL_DIR).replace("\\", "\\\\"),
            )
            tmp_vbs = INSTALL_DIR / f"_tmp_{label.lower().replace(' ','_')}.vbs"
            tmp_vbs.write_text(vbs_content, encoding="utf-8")
            result = subprocess.run(
                ["cscript.exe", "//Nologo", str(tmp_vbs)],
                capture_output=True, text=True)
            tmp_vbs.unlink(missing_ok=True)
            if Path(lnk_path).exists():
                log(f"{label} shortcut created  ✓", "green")
            else:
                raise Exception(result.stderr or "lnk not created")
        except Exception as e:
            log(f"{label} shortcut failed: {e}", "yellow")
            success = False

    if not success:
        # Final fallback: .bat file on desktop
        bat = DESKTOP / "DataBridge PRO.bat"
        bat.write_text(
            f'@echo off\nstart "" "{pythonw}" "{APP_DST}"\n',
            encoding="ascii")
        log(f"Launcher .bat created on Desktop as fallback  ✓", "yellow")

    return success

def register_uninstall():
    try:
        key_path = r"Software\Microsoft\Windows\CurrentVersion\Uninstall\DataBridge"
        key = winreg.CreateKey(winreg.HKEY_CURRENT_USER, key_path)
        uninstall_cmd = f'python "{INSTALL_DIR / "uninstall.py"}"'
        winreg.SetValueEx(key,"DisplayName",0,winreg.REG_SZ,"DataBridge PRO")
        winreg.SetValueEx(key,"DisplayVersion",0,winreg.REG_SZ,"3.0")
        winreg.SetValueEx(key,"Publisher",0,winreg.REG_SZ,"Venu Gopal Bathula")
        winreg.SetValueEx(key,"InstallLocation",0,winreg.REG_SZ,str(INSTALL_DIR))
        winreg.SetValueEx(key,"UninstallString",0,winreg.REG_SZ,uninstall_cmd)
        if ICON_DST.exists():
            winreg.SetValueEx(key,"DisplayIcon",0,winreg.REG_SZ,str(ICON_DST))
        winreg.SetValueEx(key,"NoModify",0,winreg.REG_DWORD,1)
        winreg.SetValueEx(key,"NoRepair",0,winreg.REG_DWORD,1)
        winreg.CloseKey(key)
        # Write uninstaller
        uninstall_py = INSTALL_DIR / "uninstall.py"
        uninstall_py.write_text(f"""
import os, shutil, winreg
from pathlib import Path
print("Uninstalling DataBridge PRO...")
shutil.rmtree(r"{INSTALL_DIR}", ignore_errors=True)
desktop_lnk = Path(os.environ["USERPROFILE"]) / "Desktop" / "DataBridge PRO.lnk"
desktop_bat = Path(os.environ["USERPROFILE"]) / "Desktop" / "DataBridge PRO.bat"
desktop_lnk.unlink(missing_ok=True)
desktop_bat.unlink(missing_ok=True)
sm = Path(os.environ["APPDATA"]) / "Microsoft/Windows/Start Menu/Programs/DataBridge PRO"
shutil.rmtree(sm, ignore_errors=True)
try:
    winreg.DeleteKey(winreg.HKEY_CURRENT_USER,
        r"Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\DataBridge")
except: pass
print("Done! DataBridge PRO has been uninstalled.")
input("Press Enter to close...")
""")
        log("Registered in Apps and Features  ✓", "green")
    except Exception as e:
        log(f"Registry skipped: {e}", "yellow")

def main():
    os.system("cls")
    print()
    print("  ============================================")
    print("    DataBridge PRO v3.0  -  Installer")
    print("    Data & WhatsApp Transfer Tool")
    print("  ============================================")
    print()

    if not APP_SRC.exists():
        input(f"  ERROR: databridge.py not found in {SCRIPT_DIR}\n  Press Enter to exit...")
        sys.exit(1)

    print(f"  Installing to: {INSTALL_DIR}")
    print()

    log("[1/5] Checking Python...", "bold")
    py = check_py()

    print()
    log("[2/5] Installing dependencies...", "bold")
    install_psutil(py)

    print()
    log("[3/5] Downloading ADB...", "bold")
    download_adb()
    add_to_path(ADB_DIR)

    print()
    log("[4/5] Installing app files...", "bold")
    copy_app()

    print()
    log("[5/5] Creating shortcuts...", "bold")
    create_shortcut(py)
    register_uninstall()

    print()
    print("  ============================================")
    print("   INSTALLATION COMPLETE!")
    print("  ============================================")
    print()
    print(f"  Installed to : {INSTALL_DIR}")
    print(f"  App file     : {APP_DST}")
    print(f"  ADB folder   : {ADB_DIR}")
    print(f"  Desktop      : DataBridge PRO  (shortcut)")
    print(f"  Uninstall    : Settings > Apps > DataBridge PRO")
    print()
    ans = input("  Launch DataBridge PRO now? (Y/N): ").strip().lower()
    if ans == "y":
        pythonw = Path(py).parent / "pythonw.exe"
        if not pythonw.exists(): pythonw = Path(py)
        subprocess.Popen([str(pythonw), str(APP_DST)])
        log("Launching...", "green")
    print()
    input("  Press Enter to close...")

if __name__ == "__main__":
    main()
