# ╔══════════════════════════════════════════════════════════╗
# ║         DataBridge  PRO  v3.0                           ║
# ║  © 2026 Venu Gopal Bathula. All Rights Reserved.                ║
# ║  For personal use only. Not affiliated with Meta.        ║
# ╚══════════════════════════════════════════════════════════╝

import subprocess, os, threading, time, math
from datetime import datetime
import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext, filedialog

try:
    import psutil
    PSUTIL_OK = True
except ImportError:
    PSUTIL_OK = False

WHATSAPP_SOURCE  = "/sdcard/Android/media/com.whatsapp/WhatsApp/"
WHATSAPP_ACCOUNTS= "/sdcard/Android/media/com.whatsapp/WhatsApp/accounts/"
MEMU_DEST        = "/storage/emulated/0/WhatsApp"
MEMU_ACCOUNTS    = "/storage/emulated/0/WhatsApp/accounts"

C = {
    "bg":      "#050810",
    "hdr":     "#03050d",
    "panel":   "#080c18",
    "card":    "#0c1020",
    "dim":     "#101628",
    "border":  "#1a2240",
    "border2": "#1e2d55",
    "accent":  "#00f5c4",
    "accent2": "#00c4f0",
    "blue":    "#3d8bfe",
    "amber":   "#ffb020",
    "green":   "#1ddd7a",
    "red":     "#ff3b5c",
    "purple":  "#b57bff",
    "orange":  "#ff7c3b",
    "text":    "#e8eeff",
    "muted":   "#3d4f72",
    "sub":     "#7a90bb",
    "glow":    "#00f5c420",
    "glow2":   "#3d8bfe18",
}
MONO = "Consolas"
SANS = "Segoe UI"
TITLE = "Segoe UI"
def fmono(s, b=False): return (MONO, s, "bold") if b else (MONO, s)
def fsans(s, b=False): return (SANS, s, "bold") if b else (SANS, s)
def ftitle(s, b=False): return (TITLE, s, "bold") if b else (TITLE, s)

def run_adb(cmd, device=None):
    full = (["adb", "-s", device] if device else ["adb"]) + cmd
    r = subprocess.run(full, capture_output=True, text=True)
    return r.stdout.strip(), r.stderr.strip(), r.returncode

def run_adb_priority(cmd, device=None):
    full = (["adb", "-s", device] if device else ["adb"]) + cmd
    proc = subprocess.Popen(full, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    if PSUTIL_OK:
        try:
            p = psutil.Process(proc.pid)
            cls = getattr(psutil, "BELOW_NORMAL_PRIORITY_CLASS", None)
            p.nice(cls if cls else 10)
        except: pass
    out, err = proc.communicate()
    return out.strip(), err.strip(), proc.returncode

def adb_prop(device, prop):
    o, _, _ = run_adb(["shell", "getprop", prop], device=device)
    return o.strip() or "N/A"

def folder_size(path):
    total = 0
    if os.path.exists(path):
        for dp, _, fn in os.walk(path):
            for f in fn:
                try: total += os.path.getsize(os.path.join(dp, f))
                except: pass
    return total

def fmt_size(b):
    if b < 1024: return f"{b} B"
    elif b < 1048576: return f"{b/1024:.1f} KB"
    elif b < 1073741824: return f"{b/1048576:.1f} MB"
    else: return f"{b/1073741824:.2f} GB"

def get_phone_info(device):
    def p(prop):
        return adb_prop(device, prop)

    def best(*props):
        for prop in props:
            v = p(prop).strip()
            if v and v != "N/A":
                return v
        return "N/A"

    model = best(
        "ro.product.odm.model",
        "ro.product.product.model",
        "ro.product.model",
        "ro.product.vendor.model",
        "ro.product.system.model",
    )

    brand = best("ro.product.system.brand", "ro.product.vendor.brand",
                 "ro.product.brand")
    BRAND_CLEAN = {
        "oplus": "Realme/OnePlus", "qcom": "", "msm": "",
        "sprd": "", "mtk": "",
    }
    display_brand = BRAND_CLEAN.get(brand.lower(), brand)

    MARKETING_PROPS = [
        "ro.product.marketname",
        "ro.config.marketing_name",
        "ro.product.odm.model",
        "ro.product.product.model",
        "ro.vendor.product.marketname",
        "ro.mot.product.marketname",
        "ro.product.device.market_name",
        "ro.product.vendor.name",
        "ro.mi.product.marketname",
        "ro.product.odm.marketname",
        "ro.product.odm.name",
        "ro.product.system.marketname",
        "ro.vivo.product.name",
        "persist.sys.device_marketname",
        "ro.vivo.market.name",
        "ro.oppo.market.name",
        "ro.product.oppo.marketname",
        "persist.vendor.oplus.market.name",
        "ro.vendor.oplus.market.name",
        "ro.oppo.product.name",
        "ro.semc.ms_name",
        "ro.semc.product.name",
        "ro.huawei.product.name",
        "ro.config.hw_device_name",
        "vendor.usb.product.string",
        "persist.vendor.radio.device.name",
        "ro.product.system.name",
        "ro.product.name",
    ]

    model_code = best(
        "ro.product.model",
        "ro.product.odm.model",
        "ro.product.vendor.model",
        "ro.product.system.model",
    )
    odm_model = best("ro.product.odm.model","ro.product.product.model")

    # ── FIX: Expanded MODEL_LOOKUP with Vivo, iQOO, and more ──
    MODEL_LOOKUP = {
        # iQOO
        "I2301": "iQOO Z7 Pro 5G",   "I2202": "iQOO 9 Pro",
        "I2012": "iQOO 7",            "I2105": "iQOO Z3",
        "I2010": "iQOO 3",            "I2209": "iQOO Z6 Pro 5G",
        "I2127": "iQOO Z5",           "I2206": "iQOO Z6 5G",
        "I2014": "iQOO 7 Legend",     "I2011": "iQOO Neo 5",
        "I2126": "iQOO Neo 6",        "I2227": "iQOO Z7",
        # Vivo Y series
        "V2037": "Vivo Y20",
        "V2036": "Vivo Y20i",
        "V2034": "Vivo Y20G",
        "V2041": "Vivo Y20s",
        "V2111": "Vivo Y21",
        "V2109": "Vivo Y21s",
        "V2120": "Vivo Y33s",
        "V2130": "Vivo Y33T",
        "V2204": "Vivo Y35",
        "V2207": "Vivo Y22",
        "V2209": "Vivo Y16",
        "V2254": "Vivo Y27",
        "V2318": "Vivo Y28 5G",
        "V2352": "Vivo Y100 5G",
        # Vivo V series
        "V2026": "Vivo V20",
        "V2027": "Vivo V20 SE",
        "V2031": "Vivo V20 Pro",
        "V2055": "Vivo V21 5G",
        "V2066": "Vivo V23 5G",
        "V2145": "Vivo V23e",
        "V2166": "Vivo V25",
        "V2183": "Vivo V25 Pro",
        "V2230": "Vivo V27",
        "V2243": "Vivo V27 Pro",
        "V2309": "Vivo V29",
        "V2317": "Vivo V29 Pro",
        # Vivo T series
        "V2154": "Vivo T1 5G",
        "V2171": "Vivo T1 Pro 5G",
        "V2206": "Vivo T1x",
        "V2265": "Vivo T2 5G",
        "V2303": "Vivo T2x 5G",
        # Vivo X series
        "V2145A": "Vivo X70",
        "V2202": "Vivo X80",
        "V2248": "Vivo X90",
        "V2308": "Vivo X100",
        # Realme
        "RMX3085": "Realme 8 5G",
        "RMX3081": "Realme 8",
        "RMX3092": "Realme 8 Pro",
        "RMX3195": "Realme 9 5G",
        "RMX3311": "Realme 9 Pro+",
        "RMX3472": "Realme 9 5G",
        "RMX3370": "Realme 9 Pro",
        "RMX3563": "Realme 10 Pro+",
        "RMX3686": "Realme 10",
        "RMX3785": "Realme 10 Pro",
        "RMX3888": "Realme 11",
        "RMX3830": "Realme 11 Pro",
        "RMX3834": "Realme 11 Pro+",
        "RMX3910": "Realme 12",
        "RMX3842": "Realme 12 Pro",
        "RMX3840": "Realme 12 Pro+",
        "RMX3998": "Realme 13 Pro",
        "RMX3999": "Realme 13 Pro+",
        "RMX3710": "Realme C30",
        "RMX3511": "Realme C35",
        "RMX3624": "Realme C33",
        "RMX3690": "Realme C53",
        "RMX3760": "Realme C55",
        "RMX2040": "Realme Narzo 20",
        "RMX3506": "Realme Narzo 50",
        "RMX3516": "Realme Narzo 50 Pro",
        "RMX3615": "Realme Narzo 60",
        # ── OnePlus ──────────────────────────────────────────────
        "IN2010": "OnePlus 8",         "IN2013": "OnePlus 8 Pro",
        "IN2017": "OnePlus 8T",        "IN2023": "OnePlus 9",
        "IN2025": "OnePlus 9 Pro",     "DN2101": "OnePlus 9R",
        "CPH2251": "OnePlus Nord 2",   "CPH2399": "OnePlus Nord 2T",
        "CPH2423": "OnePlus Nord 3",   "CPH2409": "OnePlus 10T",
        "CPH2413": "OnePlus 10 Pro",   "CPH2449": "OnePlus 11",
        "CPH2471": "OnePlus 11R",      "CPH2551": "OnePlus 12",
        "CPH2573": "OnePlus 12R",      "CPH2591": "OnePlus 13",
        "CPH2205": "OnePlus Nord CE",  "CPH2293": "OnePlus Nord CE 2",
        "CPH2381": "OnePlus Nord CE 2 Lite",
        "CPH2467": "OnePlus Nord CE 3",
        "CPH2491": "OnePlus Nord CE 3 Lite",
        "CPH2235": "OnePlus Nord N10", "CPH2179": "OnePlus Nord N100",
        "CPH2371": "OnePlus Nord N20", "CPH2469": "OnePlus Nord N30",
        # ── Oppo ─────────────────────────────────────────────────
        "CPH2127": "Oppo A15",         "CPH2185": "Oppo A16",
        "CPH2083": "Oppo A53",         "CPH2135": "Oppo A55",
        "CPH2325": "Oppo A57",         "CPH2339": "Oppo A57s",
        "CPH2471": "Oppo A58",         "CPH2159": "Oppo A74",
        "CPH2255": "Oppo A76",         "CPH2385": "Oppo A77",
        "CPH2477": "Oppo A78",         "CPH2579": "Oppo A79 5G",
        "CPH2173": "Oppo A94",         "CPH2357": "Oppo A96",
        "CPH2137": "Oppo F19",         "CPH2285": "Oppo F21 Pro",
        "CPH2459": "Oppo F23",         "CPH2577": "Oppo F25 Pro",
        "CPH2007": "Oppo Reno 4",      "CPH2109": "Oppo Reno 5",
        "CPH2269": "Oppo Reno 6 Pro",  "CPH2363": "Oppo Reno 7 Pro",
        "CPH2479": "Oppo Reno 8T",     "CPH2505": "Oppo Reno 10",
        "CPH2525": "Oppo Reno 10 Pro", "CPH2531": "Oppo Reno 10 Pro+",
        "CPH2631": "Oppo Reno 11",     "CPH2655": "Oppo Reno 11 Pro",
        "CPH2661": "Oppo Reno 12",     "CPH2673": "Oppo Reno 12 Pro",
        "CPH2613": "Oppo Reno 13 5G",  "CPH2619": "Oppo Reno 13 Pro 5G",
        "CPH2691": "Oppo F27 Pro+",
        # ── Samsung Galaxy S series ───────────────────────────────
        "SM-G973F": "Samsung Galaxy S10",
        "SM-G975F": "Samsung Galaxy S10+",
        "SM-G977B": "Samsung Galaxy S10 5G",
        "SM-G970F": "Samsung Galaxy S10e",
        "SM-G980F": "Samsung Galaxy S20",
        "SM-G985F": "Samsung Galaxy S20+",
        "SM-G988B": "Samsung Galaxy S20 Ultra",
        "SM-G781B": "Samsung Galaxy S20 FE",
        "SM-G991B": "Samsung Galaxy S21",
        "SM-G996B": "Samsung Galaxy S21+",
        "SM-G998B": "Samsung Galaxy S21 Ultra",
        "SM-G990B": "Samsung Galaxy S21 FE",
        "SM-G990B2":"Samsung Galaxy S21 FE",
        "SM-S901B": "Samsung Galaxy S22",
        "SM-S906B": "Samsung Galaxy S22+",
        "SM-S908B": "Samsung Galaxy S22 Ultra",
        "SM-S711B": "Samsung Galaxy S23 FE",
        "SM-S911B": "Samsung Galaxy S23",
        "SM-S916B": "Samsung Galaxy S23+",
        "SM-S918B": "Samsung Galaxy S23 Ultra",
        "SM-S921B": "Samsung Galaxy S24",
        "SM-S926B": "Samsung Galaxy S24+",
        "SM-S928B": "Samsung Galaxy S24 Ultra",
        "SM-S731B": "Samsung Galaxy S24 FE",
        "SM-S931B": "Samsung Galaxy S25",
        "SM-S936B": "Samsung Galaxy S25+",
        "SM-S938B": "Samsung Galaxy S25 Ultra",
        # Samsung Galaxy A series
        "SM-A045F": "Samsung Galaxy A04",
        "SM-A055F": "Samsung Galaxy A05",
        "SM-A057F": "Samsung Galaxy A05s",
        "SM-A125F": "Samsung Galaxy A12",
        "SM-A135F": "Samsung Galaxy A13",
        "SM-A145F": "Samsung Galaxy A14",
        "SM-A146B": "Samsung Galaxy A14 5G",
        "SM-A155F": "Samsung Galaxy A15",
        "SM-A156B": "Samsung Galaxy A15 5G",
        "SM-A165F": "Samsung Galaxy A16",
        "SM-A166B": "Samsung Galaxy A16 5G",
        "SM-A225F": "Samsung Galaxy A22",
        "SM-A226B": "Samsung Galaxy A22 5G",
        "SM-A235F": "Samsung Galaxy A23",
        "SM-A236B": "Samsung Galaxy A23 5G",
        "SM-A245F": "Samsung Galaxy A24",
        "SM-A256B": "Samsung Galaxy A25 5G",
        "SM-A266B": "Samsung Galaxy A26 5G",
        "SM-A325F": "Samsung Galaxy A32",
        "SM-A326B": "Samsung Galaxy A32 5G",
        "SM-A336B": "Samsung Galaxy A33 5G",
        "SM-A346B": "Samsung Galaxy A34 5G",
        "SM-A356B": "Samsung Galaxy A35 5G",
        "SM-A366B": "Samsung Galaxy A36 5G",
        "SM-A515F": "Samsung Galaxy A51",
        "SM-A525F": "Samsung Galaxy A52",
        "SM-A526B": "Samsung Galaxy A52 5G",
        "SM-A528B": "Samsung Galaxy A52s 5G",
        "SM-A536B": "Samsung Galaxy A53 5G",
        "SM-A546B": "Samsung Galaxy A54 5G",
        "SM-A556B": "Samsung Galaxy A55 5G",
        "SM-A566B": "Samsung Galaxy A56 5G",
        "SM-A715F": "Samsung Galaxy A71",
        "SM-A725F": "Samsung Galaxy A72",
        "SM-A736B": "Samsung Galaxy A73 5G",
        # Samsung Galaxy M series
        "SM-M135F": "Samsung Galaxy M13",
        "SM-M145F": "Samsung Galaxy M14",
        "SM-M236B": "Samsung Galaxy M23 5G",
        "SM-M336B": "Samsung Galaxy M33 5G",
        "SM-M346B": "Samsung Galaxy M34 5G",
        "SM-M356B": "Samsung Galaxy M35 5G",
        "SM-M526B": "Samsung Galaxy M52 5G",
        "SM-M536B": "Samsung Galaxy M53 5G",
        "SM-M546B": "Samsung Galaxy M54 5G",
        "SM-M556B": "Samsung Galaxy M55 5G",
        # Samsung Z/Note
        "SM-N970F": "Samsung Galaxy Note 10",
        "SM-N975F": "Samsung Galaxy Note 10+",
        "SM-N980F": "Samsung Galaxy Note 20",
        "SM-N986B": "Samsung Galaxy Note 20 Ultra",
        "SM-F711B": "Samsung Galaxy Z Flip 3",
        "SM-F721B": "Samsung Galaxy Z Flip 4",
        "SM-F731B": "Samsung Galaxy Z Flip 5",
        "SM-F741B": "Samsung Galaxy Z Flip 6",
        "SM-F926B": "Samsung Galaxy Z Fold 3",
        "SM-F936B": "Samsung Galaxy Z Fold 4",
        "SM-F946B": "Samsung Galaxy Z Fold 5",
        "SM-F956B": "Samsung Galaxy Z Fold 6",
        # ── Google Pixel codenames & model numbers ────────────────
        "GR1YH":"Google Pixel 6",    "GB7N6":"Google Pixel 6",
        "GFAN7":"Google Pixel 6 Pro","GX7AS":"Google Pixel 6a",
        "GQML3":"Google Pixel 7",    "GP4BC":"Google Pixel 7 Pro",
        "G9S9B":"Google Pixel 7a",   "GKWS6":"Google Pixel 8",
        "G1MNW":"Google Pixel 8 Pro","G9FPL":"Google Pixel 8a",
        "GP047":"Google Pixel 9",    "GP4R3":"Google Pixel 9 Pro",
        "flame":   "Google Pixel 4",     "coral":    "Google Pixel 4 XL",
        "sunfish": "Google Pixel 4a",    "bramble":  "Google Pixel 4a 5G",
        "redfin":  "Google Pixel 5",     "barbet":   "Google Pixel 5a",
        "oriole":  "Google Pixel 6",     "raven":    "Google Pixel 6 Pro",
        "bluejay": "Google Pixel 6a",    "blueberry":"Google Pixel 6a",
        "panther": "Google Pixel 7",     "cheetah":  "Google Pixel 7 Pro",
        "lynx":    "Google Pixel 7a",    "shiba":    "Google Pixel 8",
        "husky":   "Google Pixel 8 Pro", "akita":    "Google Pixel 8a",
        "tokay":   "Google Pixel 9",     "caiman":   "Google Pixel 9 Pro",
        "komodo":  "Google Pixel 9 Pro XL",
        "Pixel 4": "Google Pixel 4",    "Pixel 4 XL":"Google Pixel 4 XL",
        "Pixel 4a":"Google Pixel 4a",   "Pixel 5":  "Google Pixel 5",
        "Pixel 5a":"Google Pixel 5a",   "Pixel 6":  "Google Pixel 6",
        "Pixel 6 Pro":"Google Pixel 6 Pro","Pixel 6a":"Google Pixel 6a",
        "Pixel 7": "Google Pixel 7",    "Pixel 7 Pro":"Google Pixel 7 Pro",
        "Pixel 7a":"Google Pixel 7a",   "Pixel 8":  "Google Pixel 8",
        "Pixel 8 Pro":"Google Pixel 8 Pro","Pixel 8a":"Google Pixel 8a",
        "Pixel 9": "Google Pixel 9",    "Pixel 9 Pro":"Google Pixel 9 Pro",
        # ── Xiaomi / Redmi / POCO ────────────────────────────────
        "2201116SG":"Xiaomi 12",      "2203121C":"Xiaomi 12 Pro",
        "22071212AG":"Xiaomi 12T",    "22071212AI":"Xiaomi 12T Pro",
        "23013RK75C":"Xiaomi 13",     "2210132G":"Xiaomi 13 Pro",
        "23049PCD8G":"Xiaomi 13T",    "23078PCD5G":"Xiaomi 13T Pro",
        "24030PN60G":"Xiaomi 14",     "23116PN5BC":"Xiaomi 14 Pro",
        "2109119DG":"Xiaomi 11T",     "2109119DC":"Xiaomi 11T Pro",
        "M2012K11AG":"Xiaomi Mi 11",  "M2012K11AI":"Xiaomi Mi 11X Pro",
        "21051182G":"Xiaomi Mi 11 Lite",
        "2107113SG":"Xiaomi Mi 11 Lite 5G NE",
        "220733SFG":"Redmi 10",       "23076RN4BI":"Redmi 12",
        "24030RA62L":"Redmi 13",
        "M2006C3LG":"Redmi 9",        "M2004J19G":"Redmi 9A",
        "M2101K7AG":"Redmi Note 10",  "M2101K7AI":"Redmi Note 10 Pro",
        "M2101K7BG":"Redmi Note 10S",
        "21061119AG":"Redmi Note 11", "2201117TG":"Redmi Note 11 Pro",
        "22041219PG":"Redmi Note 11S","2207117BPG":"Redmi Note 12",
        "22111317G":"Redmi Note 12 Pro","22111317I":"Redmi Note 12 Pro+",
        "23076RA4BI":"Redmi Note 13", "23090RA98G":"Redmi Note 13 Pro",
        "23090RA98I":"Redmi Note 13 Pro+",
        "24031PN0DC":"Redmi Note 14", "24095PN0DC":"Redmi Note 14 Pro",
        "24095PN0EC":"Redmi Note 14 Pro+",
        "M2007J17G":"Redmi Note 9",   "M2003J15SG":"Redmi Note 9 Pro",
        "PGKM10":"POCO X3",           "M2007J20CG":"POCO X3 NFC",
        "M2102J20SG":"POCO X3 Pro",   "2201116PG":"POCO X4 Pro 5G",
        "22071219CG":"POCO X5",       "22101320G":"POCO X5 Pro",
        "23013PC75G":"POCO X6",       "23013PC75I":"POCO X6 Pro",
        "2201117PG":"POCO F4",        "23049PCD8G":"POCO F5",
        "MZB0F4GIN":"POCO M5",        "22120PC21G":"POCO M5s",
        "22111316G":"POCO M6 Pro",
        # Xiaomi codenames
        "alioth":"Xiaomi Mi 11X Pro", "vayu":"POCO X3 Pro",
        "sweet":"Redmi Note 10 Pro",  "rosemary":"Redmi Note 10S",
        "mojito":"Redmi Note 10",     "merlin":"Redmi Note 9",
        "curtana":"Redmi Note 9 Pro", "surya":"POCO X3",
        "lisa":"Xiaomi Mi 11 Lite 5G NE",
        "chartreuse":"Redmi Note 13 Pro","mondrian":"Xiaomi 13T",
        # ── Vivo ─────────────────────────────────────────────────
        "V2037":"Vivo Y20",    "V2036":"Vivo Y20i",
        "V2034":"Vivo Y20G",   "V2041":"Vivo Y20s",
        "V2111":"Vivo Y21",    "V2109":"Vivo Y21s",
        "V2120":"Vivo Y33s",   "V2130":"Vivo Y33T",
        "V2204":"Vivo Y35",    "V2207":"Vivo Y22",
        "V2209":"Vivo Y16",    "V2254":"Vivo Y27",
        "V2318":"Vivo Y28 5G", "V2352":"Vivo Y100 5G",
        "V2401":"Vivo Y18",    "V2412":"Vivo Y28s 5G",
        "V2421":"Vivo Y38 5G", "V2505":"Vivo Y29 5G",
        "V2026":"Vivo V20",    "V2031":"Vivo V20 Pro",
        "V2055":"Vivo V21 5G", "V2066":"Vivo V23 5G",
        "V2166":"Vivo V25",    "V2183":"Vivo V25 Pro",
        "V2230":"Vivo V27",    "V2243":"Vivo V27 Pro",
        "V2309":"Vivo V29",    "V2317":"Vivo V29 Pro",
        "V2430":"Vivo V40",    "V2434":"Vivo V40 Pro",
        "V2154":"Vivo T1 5G",  "V2171":"Vivo T1 Pro 5G",
        "V2265":"Vivo T2 5G",  "V2303":"Vivo T2x 5G",
        "V2340":"Vivo T3 5G",  "V2342":"Vivo T3 Pro 5G",
        "V2202":"Vivo X80",    "V2248":"Vivo X90",
        "V2308":"Vivo X100",   "V2406":"Vivo X100 Pro",
        "V2416":"Vivo X200",   "V2418":"Vivo X200 Pro",
        # ── Motorola ─────────────────────────────────────────────
        "XT2163-4":"Motorola Moto G22","XT2165-4":"Motorola Moto G32",
        "XT2167-2":"Motorola Moto G52","XT2169-1":"Motorola Moto G62 5G",
        "XT2237-2":"Motorola Moto G13","XT2239-2":"Motorola Moto G23",
        "XT2241-1":"Motorola Moto G53","XT2251-1":"Motorola Moto G84",
        "XT2255-2":"Motorola Moto G54","XT2311-5":"Motorola Moto G14",
        "XT2331-4":"Motorola Moto G24","XT2333-3":"Motorola Moto G34",
        "XT2341-4":"Motorola Moto G45","XT2343-5":"Motorola Moto G85",
        "XT2355-4":"Motorola Moto G64","XT2413-3":"Motorola Moto G35",
        "XT2415-4":"Motorola Moto G15",
        "XT2141-1":"Motorola Moto Edge 20",
        "XT2201-3":"Motorola Moto Edge 30",
        "XT2203-1":"Motorola Moto Edge 30 Pro",
        "XT2207-1":"Motorola Moto Edge 30 Ultra",
        "XT2253-1":"Motorola Moto Edge 40",
        "XT2257-1":"Motorola Moto Edge 40 Pro",
        "XT2301-4":"Motorola Moto Edge 50",
        "XT2307-1":"Motorola Moto Edge 50 Pro",
        "XT2309-1":"Motorola Moto Edge 50 Fusion",
        "XT2321-2":"Motorola Moto Edge 50 Ultra",
        "moto g45 5G":"Motorola Moto G45 5G",
        "moto g85 5G":"Motorola Moto G85 5G",
        "moto g64 5G":"Motorola Moto G64 5G",
        "moto g54 5G":"Motorola Moto G54 5G",
        "moto g35 5G":"Motorola Moto G35 5G",
        "moto g24":   "Motorola Moto G24",
        "moto g14":   "Motorola Moto G14",
        "moto g15":   "Motorola Moto G15",
        "edge 50 fusion":"Motorola Edge 50 Fusion",
        "edge 50 pro":   "Motorola Edge 50 Pro",
        "edge 50 ultra": "Motorola Edge 50 Ultra",
        # ── Nokia ────────────────────────────────────────────────
        "TA-1150":"Nokia 3.2",   "TA-1156":"Nokia 4.2",
        "TA-1157":"Nokia 6.2",   "TA-1187":"Nokia 7.2",
        "TA-1277":"Nokia G10",   "TA-1296":"Nokia G20",
        "TA-1322":"Nokia G50",   "TA-1353":"Nokia G11",
        "TA-1356":"Nokia G21",   "TA-1387":"Nokia G60 5G",
        "TA-1432":"Nokia G42 5G","TA-1459":"Nokia C22",
        "TA-1484":"Nokia C32",
        # ── Tecno ────────────────────────────────────────────────
        "KI5k":"Tecno Spark 10",  "KI5":"Tecno Spark 10 Pro",
        "KJ5":"Tecno Spark 20",   "KJ7":"Tecno Spark 20 Pro",
        "CI6n":"Tecno Camon 19",  "CI7":"Tecno Camon 19 Pro",
        "CJ6":"Tecno Camon 20",   "CJ7":"Tecno Camon 20 Pro",
        "CK8":"Tecno Camon 30",   "CK8n":"Tecno Camon 30 Pro",
        "AE7":"Tecno Pova 4",     "AE8":"Tecno Pova 5",
        "AF8":"Tecno Pova 6",
        # ── Infinix ──────────────────────────────────────────────
        "X6812":"Infinix Hot 11s","X6813":"Infinix Hot 12",
        "X6823":"Infinix Hot 20", "X6831":"Infinix Hot 30",
        "X6851":"Infinix Hot 40", "X6855":"Infinix Hot 40 Pro",
        "X680":"Infinix Note 12", "X697":"Infinix Note 12 Pro",
        "X6833C":"Infinix Note 30","X6851A":"Infinix Note 40",
        # ── Nothing Phone ─────────────────────────────────────────
        "A063":"Nothing Phone (1)","A065":"Nothing Phone (2)",
        "A142":"Nothing Phone (2a)","Spacewar":"Nothing Phone (1)",
        "Pong":"Nothing Phone (2)","Pacman":"Nothing Phone (2a)",
        # ── ASUS ─────────────────────────────────────────────────
        "ASUS_I006D":"ASUS ROG Phone 5","ASUS_AI2201":"ASUS ROG Phone 6",
        "ASUS_AI2301":"ASUS ROG Phone 7","ASUS_AI2401":"ASUS ROG Phone 8",
        "ASUS_I002D":"ASUS ZenFone 8",  "ASUS_AI2205":"ASUS Zenfone 9",
        "ASUS_AI2302":"ASUS Zenfone 10",
        # ── Sony ─────────────────────────────────────────────────
        "XQ-BC72":"Sony Xperia 10 III","XQ-BT52":"Sony Xperia 1 III",
        "XQ-CC54":"Sony Xperia 10 IV", "XQ-CT54":"Sony Xperia 1 IV",
        "XQ-DC54":"Sony Xperia 10 V",  "XQ-DQ54":"Sony Xperia 1 V",
        "XQ-EC54":"Sony Xperia 10 VI", "XQ-EQ54":"Sony Xperia 1 VI",
        # ── Huawei / Honor ────────────────────────────────────────
        "ELE-L29":"Huawei P30 Pro",  "VOG-L29":"Huawei P30",
        "JNY-LX1":"Huawei P40 Lite", "ANA-LX4":"Huawei P40",
        "ALS-L29":"Huawei P40 Pro",  "NEN-L22":"Huawei nova 9",
        "NMO-LX1":"Huawei nova 10",  "MAO-LX9":"Huawei nova 5T",
        # ── Lava / Micromax ───────────────────────────────────────
        "LZG401":"Lava Blaze",       "LZG402":"Lava Blaze 5G",
        "LZG501":"Lava Blaze 2",     "LZG411":"Lava Agni 2 5G",
    }

    # ── CODENAME LOOKUP — Android internal device codenames ────────────────
    # These are returned by ro.product.device / ro.product.odm.device
    CODENAME_LOOKUP = {
        # ── Oppo codenames ────────────────────────────────────────
        "ovaltine":    "Oppo Reno 12",
        "ovaltinepro": "Oppo Reno 12 Pro",
        "messi":       "Oppo Reno 11",
        "peqm10":      "Oppo Reno 11 Pro",
        "ferrari":     "Oppo Reno 10",
        "PHX110":      "Oppo Find X7",
        "PHX210":      "Oppo Find X7 Ultra",
        "CPH2707":     "Oppo A3 Pro",
        # ── OnePlus codenames ─────────────────────────────────────
        "ossi":        "OnePlus 10T",          # CPH2413 — confirmed
        "ossiepro":    "OnePlus 10T",
        "salami":      "OnePlus 12",
        "aston":       "OnePlus 12R",
        "waffle":      "OnePlus 13",
        "instantnoodle":"OnePlus 8",
        "instantnoodlep":"OnePlus 8 Pro",
        "kebab":       "OnePlus 8T",
        "lemonade":    "OnePlus 9",
        "lemonadep":   "OnePlus 9 Pro",
        "lemonades":   "OnePlus 9R",
        "lahaina":     "OnePlus 10 Pro",
        "ovaltine":    "OnePlus 10T",
        "linchen":     "OnePlus Nord 3",
        "ivan":        "OnePlus Nord CE 3",
        "pickle":      "OnePlus Nord 2",
        "denniz":      "OnePlus Nord 2T",
        "porsche":     "OnePlus Nord CE 2",
        "oscar":       "OnePlus Nord CE 2 Lite",
        "caihong":     "OnePlus Pad 2",
        "ossipad":     "OnePlus Pad 2 Pro",
        # ── Realme codenames ──────────────────────────────────────
        "RMX3998L1":   "Realme 13 Pro",
        "RMX3999L1":   "Realme 13 Pro+",
        "RMX3910L1":   "Realme 12",
        "RMX3840L1":   "Realme 12 Pro+",
        "RMX3888L1":   "Realme 11",
        "RMX3830L1":   "Realme 11 Pro",
        "RMX3834L1":   "Realme 11 Pro+",
        "juice":       "Realme 8",
        "RMX3081":     "Realme 8",
        "race":        "Realme GT",
        "bitra":       "Realme 8i",
        "RMX3231":     "Realme 8i",
        "RE54BFL1":    "Realme C67",
        # ── Xiaomi / Redmi codenames ──────────────────────────────
        "alioth":      "Xiaomi Mi 11X / POCO F3",
        "aliothin":    "Xiaomi Mi 11X",
        "socrates":    "Xiaomi 14 Ultra",
        "houji":       "Xiaomi 14",
        "shennong":    "Xiaomi 14 Pro",
        "zircon":      "Xiaomi 13T Pro",
        "mondrian":    "Xiaomi 13T",
        "marble":      "POCO F5",
        "garnet":      "Redmi Note 13 Pro",
        "ruby":        "Redmi Note 13",
        "sky":         "Redmi Note 13 Pro+",
        "thor":        "Redmi Note 14 Pro",
        "chime":       "Redmi Note 14",
        "tapas":       "POCO X6 Pro",
        "duchamp":     "POCO X6",
        "pissarro":    "Redmi Note 12 Pro",
        "pissarropro": "Redmi Note 12 Pro+",
        "sunstone":    "Redmi Note 12",
        "sweet":       "Redmi Note 10 Pro",
        "sweetin":     "Redmi Note 10 Pro",
        "sweetpro":    "Redmi Note 10 Pro Max",
        "rosemary":    "Redmi Note 10S",
        "mojito":      "Redmi Note 10",
        "camellian":   "Redmi Note 10T",
        "merlin":      "Redmi Note 9",
        "curtana":     "Redmi Note 9 Pro",
        "excalibur":   "Redmi Note 9 Pro Max",
        "miatoll":     "Redmi Note 9 Pro",
        "surya":       "POCO X3",
        "karna":       "POCO X3 Pro",
        "vayu":        "POCO X3 Pro",
        "lisa":        "Xiaomi Mi 11 Lite 5G NE",
        "angelica":    "Redmi 9C",
        "dandelion":   "Redmi 9A",
        "pine":        "Redmi 9",
        "gauguin":     "Redmi Note 10 Pro",
        "gauguinpro":  "Redmi Note 10 Pro Max",
        "cezanne":     "Redmi Note 10S",
        "chartreuse":  "Redmi Note 13 Pro",
        "sapphire":    "Redmi Note 14 Pro+",
        "aurora":      "Xiaomi 15",
        "diting":      "Xiaomi 12S Ultra",
        "thor":        "Redmi Note 14 Pro",
        # ── Vivo codenames ────────────────────────────────────────
        "PD2454":      "Vivo X200 Pro",
        "PD2450":      "Vivo X200",
        "PD2416":      "Vivo X100 Ultra",
        "PD2406":      "Vivo X100 Pro",
        "PD2308":      "Vivo X100",
        "PD2347":      "Vivo V40 Pro",
        "PD2430":      "Vivo V40",
        "PD2317":      "Vivo V29 Pro",
        "PD2309":      "Vivo V29",
        "PD2243":      "Vivo V27 Pro",
        "PD2230":      "Vivo V27",
        "PD2183":      "Vivo V25 Pro",
        "PD2166":      "Vivo V25",
        "PD2342":      "Vivo T3 Pro 5G",
        "PD2340":      "Vivo T3 5G",
        "PD2303":      "Vivo T2x 5G",
        "PD2265":      "Vivo T2 5G",
        "PD2171":      "Vivo T1 Pro 5G",
        "PD2154":      "Vivo T1 5G",
        "PD2421":      "Vivo Y38 5G",
        "PD2412":      "Vivo Y28s 5G",
        "PD2318":      "Vivo Y28 5G",
        "PD2254":      "Vivo Y27",
        "PD2209":      "Vivo Y16",
        "PD2207":      "Vivo Y22",
        "PD2204":      "Vivo Y35",
        "PD2120":      "Vivo Y33s",
        "PD2111":      "Vivo Y21",
        "PD2109":      "Vivo Y21s",
        # ── Samsung codenames ─────────────────────────────────────
        "a55x":        "Samsung Galaxy A55 5G",
        "a54x":        "Samsung Galaxy A54 5G",
        "a35x":        "Samsung Galaxy A35 5G",
        "a34x":        "Samsung Galaxy A34 5G",
        "a25x":        "Samsung Galaxy A25 5G",
        "a24x":        "Samsung Galaxy A24",
        "a15x":        "Samsung Galaxy A15 5G",
        "a15":         "Samsung Galaxy A15",
        "a14x":        "Samsung Galaxy A14 5G",
        "a14":         "Samsung Galaxy A14",
        "m55x":        "Samsung Galaxy M55 5G",
        "m54x":        "Samsung Galaxy M54 5G",
        "m35x":        "Samsung Galaxy M35 5G",
        "m34x":        "Samsung Galaxy M34 5G",
        "r9q":         "Samsung Galaxy S21 FE",
        "b0q":         "Samsung Galaxy S22 Ultra",
        "gts8":        "Samsung Galaxy Tab S8",
        "gts9":        "Samsung Galaxy Tab S9",
        "dm3q":        "Samsung Galaxy S23 Ultra",
        "dm1q":        "Samsung Galaxy S23",
        "dm2q":        "Samsung Galaxy S23+",
        "e1q":         "Samsung Galaxy S24",
        "e2q":         "Samsung Galaxy S24+",
        "e3q":         "Samsung Galaxy S24 Ultra",
        "f1q":         "Samsung Galaxy S25",
        "f2q":         "Samsung Galaxy S25+",
        "f3q":         "Samsung Galaxy S25 Ultra",
        "q2q":         "Samsung Galaxy Z Fold 3",
        "q4q":         "Samsung Galaxy Z Fold 4",
        "q5q":         "Samsung Galaxy Z Fold 5",
        "b4q":         "Samsung Galaxy Z Flip 4",
        "b5q":         "Samsung Galaxy Z Flip 5",
        # ── Google Pixel codenames ────────────────────────────────
        "flame":       "Google Pixel 4",
        "coral":       "Google Pixel 4 XL",
        "sunfish":     "Google Pixel 4a",
        "bramble":     "Google Pixel 4a 5G",
        "redfin":      "Google Pixel 5",
        "barbet":      "Google Pixel 5a",
        "oriole":      "Google Pixel 6",
        "raven":       "Google Pixel 6 Pro",
        "bluejay":     "Google Pixel 6a",
        "blueberry":   "Google Pixel 6a",
        "panther":     "Google Pixel 7",
        "cheetah":     "Google Pixel 7 Pro",
        "lynx":        "Google Pixel 7a",
        "shiba":       "Google Pixel 8",
        "husky":       "Google Pixel 8 Pro",
        "akita":       "Google Pixel 8a",
        "tokay":       "Google Pixel 9",
        "caiman":      "Google Pixel 9 Pro",
        "komodo":      "Google Pixel 9 Pro XL",
        "comet":       "Google Pixel 9 Pro Fold",
        # ── Motorola codenames ────────────────────────────────────
        "hiphala":     "Motorola Moto G45 5G",
        "hiphi":       "Motorola Moto G85 5G",
        "hilfika":     "Motorola Moto G64 5G",
        "hidalgo":     "Motorola Moto G54 5G",
        "hippo":       "Motorola Moto G35 5G",
        "hipaa":       "Motorola Moto G24",
        "hikaruone":   "Motorola Moto G15",
        "tundra":      "Motorola Edge 30 Ultra",
        "denver":      "Motorola Edge 30 Pro",
        "dubai":       "Motorola Edge 30",
        "cancunf":     "Motorola Edge 40",
        "bangkokf":    "Motorola Edge 40 Pro",
        "manaus":      "Motorola Edge 50",
        "manauspro":   "Motorola Edge 50 Pro",
        "manausfusion":"Motorola Edge 50 Fusion",
        "manausultra": "Motorola Edge 50 Ultra",
        # ── Nothing Phone codenames ───────────────────────────────
        "Spacewar":    "Nothing Phone (1)",
        "spacewar":    "Nothing Phone (1)",
        "Pong":        "Nothing Phone (2)",
        "pong":        "Nothing Phone (2)",
        "Pacman":      "Nothing Phone (2a)",
        "pacman":      "Nothing Phone (2a)",
        "PacmanPlus":  "Nothing Phone (2a) Plus",
        # ── ASUS codenames ────────────────────────────────────────
        "ASUS_AI2302": "ASUS Zenfone 10",
        "ASUS_AI2205": "ASUS Zenfone 9",
        "ASUS_AI2201": "ASUS ROG Phone 6",
        "ASUS_AI2301": "ASUS ROG Phone 7",
        "ASUS_AI2401": "ASUS ROG Phone 8",
        # ── iQOO codenames ────────────────────────────────────────
        "PD2454F":     "iQOO 13",
        "PD2398F":     "iQOO 12",
        "PD2307F":     "iQOO 11",
        "PD2255F":     "iQOO 10 Pro",
        "PD2209F":     "iQOO Z7 Pro 5G",
        "PD2206F":     "iQOO Z6 5G",
        "I2301":       "iQOO Z7 Pro 5G",
        "I2202":       "iQOO 9 Pro",
        "I2126":       "iQOO Neo 6",
        "I2011":       "iQOO Neo 5",
        # ── Tecno codenames ───────────────────────────────────────
        "TECNO KJ5":   "Tecno Spark 20",
        "TECNO CK8":   "Tecno Camon 30",
        "TECNO AF8":   "Tecno Pova 6",
        # ── Honor codenames ───────────────────────────────────────
        "ALN-AL00":    "Honor Magic6 Pro",
        "BVL-AN10":    "Honor 200",
        "CRT-AN00":    "Honor 90",
        "NTN-AN00":    "Honor 70",
        "ANY-LX1":     "Honor 8X",
        "REA-NX9":     "Honor Magic5 Pro",
        # ── Sony codenames ────────────────────────────────────────
        "pdx234":      "Sony Xperia 1 V",
        "pdx237":      "Sony Xperia 10 V",
        "pdx224":      "Sony Xperia 1 IV",
        "pdx225":      "Sony Xperia 10 IV",
        "pdx215":      "Sony Xperia 1 III",
        "pdx213":      "Sony Xperia 10 III",
        # ── Huawei codenames ──────────────────────────────────────
        "NOH-NX9":     "Huawei Mate 40 Pro",
        "OCE-AN10":    "Huawei nova 8",
        "NEN-AN00":    "Huawei nova 9",
        "NCO-AN00":    "Huawei nova 9 SE",
        "NMO-AN00":    "Huawei nova 10",
    }

    if model_code in MODEL_LOOKUP:
        full_name = MODEL_LOOKUP[model_code]
    elif device_codename in CODENAME_LOOKUP:
        full_name = CODENAME_LOOKUP[device_codename]
    elif device_codename in MODEL_LOOKUP:
        full_name = MODEL_LOOKUP[device_codename]
    elif odm_model != "N/A" and " " in odm_model and odm_model != model_code:
        full_name = odm_model
    else:
        full_name = None
        for prop in MARKETING_PROPS:
            v = p(prop).strip()
            if not v or v == "N/A" or len(v) < 3:
                continue
            if v == model_code:
                continue
            if " " in v:
                full_name = v
                break
            if not v.isupper() and v != model_code:
                full_name = v
                break

    if not full_name:
        if display_brand and display_brand.lower() not in ("n/a", ""):
            full_name = f"{display_brand} {model_code}"
        else:
            full_name = model_code

    serial = device

    import re

    def is_valid_imei(v):
        """Check if string is a valid 15-digit IMEI."""
        v = v.strip().replace("-","").replace(" ","")
        return v.isdigit() and len(v) == 15

    def extract_from_service(raw):
        """Extract IMEI digits from iphonesubinfo service call output."""
        imei = ""
        for part in raw.split("'"):
            c = part.replace(".", "").strip()
            if c.isdigit() and len(c) > 3:
                imei += c
        return imei[:15] if len(imei) >= 15 else None

    def get_imei_all():
        """
        Try every known method to get IMEI 1 and IMEI 2.
        Returns (imei1, imei2) strings.
        """
        imei1 = None
        imei2 = None

        # ── Method 1: iphonesubinfo service call (standard) ──────
        # call_id 1 = IMEI1, call_id 3 = IMEI2 (older Android)
        # call_id 1 = IMEI1, call_id 12 = IMEI2 (Android 10+)
        for call_id in ["1"]:
            raw, _, _ = run_adb(
                ["shell", "service", "call", "iphonesubinfo", call_id],
                device=device)
            val = extract_from_service(raw)
            if val and is_valid_imei(val):
                imei1 = val
                break

        for call_id in ["3", "12", "4"]:
            raw, _, _ = run_adb(
                ["shell", "service", "call", "iphonesubinfo", call_id],
                device=device)
            val = extract_from_service(raw)
            if val and is_valid_imei(val) and val != imei1:
                imei2 = val
                break

        # ── Method 2: getprop — various IMEI props ───────────────
        if not imei1:
            for prop in [
                "gsm.imei",
                "ril.imei",
                "ril.gsm.imei",
                "persist.radio.imei",
                "persist.ril.imei",
                "gsm.imei.1",
                "ril.imei.1",
                "persist.radio.imei1",
            ]:
                v, _, _ = run_adb(["shell", "getprop", prop], device=device)
                v = v.strip().strip("[]").split(",")[0].strip()
                if is_valid_imei(v):
                    imei1 = v
                    break

        if not imei2:
            for prop in [
                "gsm.imei.2",
                "ril.imei.2",
                "persist.radio.imei2",
                "persist.ril.imei2",
            ]:
                v, _, _ = run_adb(["shell", "getprop", prop], device=device)
                v = v.strip().strip("[]").split(",")[0].strip()
                if is_valid_imei(v) and v != imei1:
                    imei2 = v
                    break

        # ── Method 3: dumpsys phone ──────────────────────────────
        if not imei1 or not imei2:
            raw, _, _ = run_adb(
                ["shell", "dumpsys", "phone"], device=device)
            if raw:
                # Look for IMEI in dumpsys output
                found = re.findall(r'(?:imei|IMEI)[^\d]*(\d{15})', raw, re.IGNORECASE)
                if found and not imei1:
                    imei1 = found[0]
                if len(found) > 1 and not imei2 and found[1] != imei1:
                    imei2 = found[1]

        # ── Method 4: dumpsys iphonesubinfo ─────────────────────
        if not imei1 or not imei2:
            raw, _, _ = run_adb(
                ["shell", "dumpsys", "iphonesubinfo"], device=device)
            if raw:
                found = re.findall(r'\d{15}', raw)
                for f in found:
                    if is_valid_imei(f):
                        if not imei1:
                            imei1 = f
                        elif f != imei1 and not imei2:
                            imei2 = f
                            break

        # ── Method 5: AT command via shell ───────────────────────
        if not imei1:
            raw, _, rc = run_adb(
                ["shell", "echo", "-e", "AT+CGSN\\r", ">", "/dev/smd0"],
                device=device)
            if rc == 0:
                raw2, _, _ = run_adb(
                    ["shell", "cat", "/dev/smd0"], device=device)
                found = re.findall(r'\d{15}', raw2)
                if found and is_valid_imei(found[0]):
                    imei1 = found[0]

        # ── Method 6: settings content resolver ─────────────────
        if not imei1:
            raw, _, _ = run_adb(
                ["shell", "settings", "get", "secure", "android_id"],
                device=device)
            # android_id is not IMEI but useful as fallback identifier

        # ── Detect if protected (dots pattern) ───────────────────
        def check_protected(call_id):
            raw, _, _ = run_adb(
                ["shell", "service", "call", "iphonesubinfo", call_id],
                device=device)
            dots = len(re.findall(r"\.", raw))
            return dots >= 8  # Protected IMEI returns dot pattern

        # Build final results
        if not imei1:
            if check_protected("1"):
                imei1 = "🔒 Protected (15-digit, needs root)"
            else:
                imei1 = "Not available"

        if not imei2:
            if check_protected("3"):
                imei2 = "🔒 Protected (15-digit, needs root)"
            else:
                imei2 = "Single SIM / Not available"

        return imei1, imei2

    imei1, imei2 = get_imei_all()

    return {
        "Full Name":  full_name,
        "Model No":   model_code,
        "Serial No":  serial,
        "IMEI 1":     imei1,
        "IMEI 2":     imei2,
    }


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("DataBridge  PRO  v3.0")
        self.geometry("1020x900")
        self.minsize(960,800)
        self.resizable(True, True)
        self.configure(bg=C["bg"])
        self.phone_id=None; self.memu_id=None
        self._cancel_flag=False; self.selected_folder=None
        self.external_path=None; self._timer_running=False; self._speed_running=False
        # PC Transfer state
        self._pt_cancel_flag=False; self._pt_timer_running=False
        self._pt_speed_running=False; self._pt_start_time=0
        self._pt_src=None; self._pt_dst=None
        self._build()

    def _build(self):
        self._hdr()
        self._tab_bar()

        # ── Tab frames ────────────────────────────────────────
        self._tab_container = tk.Frame(self, bg=C["bg"])
        self._tab_container.pack(fill="both", expand=True)

        # Whatsapp backup tab
        self._tab_wa  = self._make_scroll_frame(self._tab_container)
        # PC Transfer tab
        self._tab_pc  = self._make_scroll_frame(self._tab_container)

        # Build content into each tab
        self._pack_target = self._tab_wa["inner"]
        self._devices_section()
        self._device_info_section()
        self._source_section()
        self._folder_section()
        self._action_row()
        self._progress_section()
        self._console_section()
        self._footer()

        self._pack_target = self._tab_pc["inner"]
        self._pc_transfer_tab()

        # Show WhatsApp tab by default
        self._show_tab("wa")

        self.after(50,  self._scroll_top)
        self.after(200, self._scroll_top)
        self._log("DataBridge PRO v3.0 ready.  Click  SCAN DEVICES  to begin.\n","head")

    def _make_scroll_frame(self, parent):
        """Create a scrollable frame and return dict with canvas/inner."""
        container = tk.Frame(parent, bg=C["bg"])
        canvas = tk.Canvas(container, bg=C["bg"], highlightthickness=0)
        scrollbar = ttk.Scrollbar(container, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side="right", fill="y")
        canvas.pack(side="left", fill="both", expand=True)
        inner = tk.Frame(canvas, bg=C["bg"])
        win = canvas.create_window((0,0), window=inner, anchor="nw")
        canvas.bind("<Configure>", lambda e,c=canvas,w=win: c.itemconfig(w, width=e.width))
        inner.bind("<Configure>", lambda e,c=canvas: c.configure(scrollregion=c.bbox("all")))
        canvas.bind_all("<MouseWheel>",
            lambda e: self._active_canvas().yview_scroll(int(-1*(e.delta/120)),"units"))
        return {"container": container, "canvas": canvas, "inner": inner}

    def _active_canvas(self):
        return self._tab_wa["canvas"] if self._active_tab=="wa" else self._tab_pc["canvas"]

    def _scroll_top(self):
        self._tab_wa["canvas"].yview_moveto(0.0)

    def _tab_bar(self):
        """Render the two tab buttons below the header."""
        bar = tk.Frame(self, bg=C["hdr"])
        bar.pack(fill="x")
        self._active_tab = "wa"
        self._tbtn_wa = tk.Button(bar,
            text="📱  WhatsApp Backup",
            font=fsans(10,True), relief="flat", cursor="hand2",
            padx=24, pady=10,
            bg=C["accent"], fg=C["hdr"],
            activebackground=C["accent"],
            command=lambda: self._show_tab("wa"))
        self._tbtn_wa.pack(side="left")
        self._tbtn_pc = tk.Button(bar,
            text="💾  PC / HDD Transfer",
            font=fsans(10,True), relief="flat", cursor="hand2",
            padx=24, pady=10,
            bg=C["dim"], fg=C["sub"],
            activebackground=C["border2"],
            command=lambda: self._show_tab("pc"))
        self._tbtn_pc.pack(side="left")
        tk.Frame(bar, bg=C["border2"], height=1).pack(fill="x", side="bottom")

    def _show_tab(self, tab):
        self._active_tab = tab
        self._tab_wa["container"].pack_forget()
        self._tab_pc["container"].pack_forget()
        if tab == "wa":
            self._tab_wa["container"].pack(fill="both", expand=True)
            self._tbtn_wa.config(bg=C["accent"], fg=C["hdr"])
            self._tbtn_pc.config(bg=C["dim"],    fg=C["sub"])
        else:
            self._tab_pc["container"].pack(fill="both", expand=True)
            self._tbtn_pc.config(bg=C["orange"], fg=C["hdr"])
            self._tbtn_wa.config(bg=C["dim"],    fg=C["sub"])

    def _hdr(self):
        bar = tk.Frame(self, bg=C["hdr"], height=3)
        bar.pack(fill="x")
        for col, w in [(C["accent"],200),(C["accent2"],200),(C["blue"],200),("#1a2240",1000)]:
            tk.Frame(bar, bg=col, height=3, width=w).pack(side="left")

        h = tk.Frame(self, bg=C["hdr"])
        h.pack(fill="x")

        cv = tk.Canvas(h, width=56, height=56, bg=C["hdr"], highlightthickness=0)
        cv.pack(side="left", padx=(20,12), pady=12)
        pts_outer = []
        for i in range(6):
            a = math.pi*(60*i-90)/180
            pts_outer += [28+24*math.cos(a), 28+24*math.sin(a)]
        cv.create_polygon(pts_outer, fill="#001f18", outline=C["accent"], width=1)
        pts = []
        for i in range(6):
            a = math.pi*(60*i-90)/180
            pts += [28+18*math.cos(a), 28+18*math.sin(a)]
        cv.create_polygon(pts, fill=C["accent"], outline="")
        cv.create_text(28, 28, text="DBP", font=fmono(8,True), fill=C["hdr"])

        tf = tk.Frame(h, bg=C["hdr"])
        tf.pack(side="left", pady=12)
        tk.Label(tf, text="DataBridge",
                 font=(TITLE, 20, "bold"), bg=C["hdr"],
                 fg=C["text"]).pack(anchor="w")
        sub_row = tk.Frame(tf, bg=C["hdr"])
        sub_row.pack(anchor="w")
        tk.Label(sub_row, text="PRO", font=fmono(7,True),
                 bg=C["accent"], fg=C["hdr"],
                 padx=5, pady=1).pack(side="left", padx=(0,6))
        tk.Label(sub_row, text="EDITION  v3.0   ·   DATA & WHATSAPP TRANSFER TOOL",
                 font=fmono(7), bg=C["hdr"], fg=C["muted"]).pack(side="left")

        br = tk.Frame(h, bg=C["hdr"])
        br.pack(side="right", padx=18, pady=16)
        badges = [
            ("ADB",    C["accent"],  C["hdr"]),
            ("PSUTIL" if PSUTIL_OK else "NO PSUTIL",
             C["blue"] if PSUTIL_OK else C["muted"], "white"),
            ("PRO",    C["amber"],   C["hdr"]),
            ("v3.0",   C["purple"],  "white"),
        ]
        for txt, bg, fg in badges:
            f = tk.Frame(br, bg=bg, padx=1, pady=1)
            f.pack(side="left", padx=3)
            tk.Label(f, text=f" {txt} ", font=fmono(7,True),
                     bg=bg, fg=fg, padx=7, pady=3).pack()

        sep = tk.Frame(self, bg=C["hdr"], height=1)
        sep.pack(fill="x")
        tk.Frame(sep, bg=C["accent"], height=1, width=300).place(x=0, y=0)

    def _sec(self,text):
        p=getattr(self,"_pack_target",self)
        row=tk.Frame(p,bg=C["bg"]); row.pack(fill="x",padx=16,pady=(12,4))
        tk.Frame(row,bg=C["accent"],width=3,height=14).pack(side="left",padx=(0,8))
        tk.Label(row,text=text,font=fmono(7,True),bg=C["bg"],
                 fg=C["accent"]).pack(side="left")
        tk.Frame(row,bg=C["border2"],height=1).pack(
            side="left",fill="x",expand=True,padx=(12,0))

    def _card(self):
        p=getattr(self,"_pack_target",self)
        outer=tk.Frame(p,bg=C["border2"],padx=1,pady=1)
        outer.pack(fill="x",padx=16,pady=(0,4))
        f=tk.Frame(outer,bg=C["card"])
        f.pack(fill="x")
        return f

    def _devices_section(self):
        self._sec("CONNECTED DEVICES")
        card=self._card()
        row=tk.Frame(card,bg=C["card"]); row.pack(fill="x",padx=12,pady=10)

        self.ptile=tk.Frame(row,bg=C["dim"],highlightbackground=C["border2"],highlightthickness=1)
        self.ptile.pack(side="left",fill="x",expand=True,padx=(0,8))
        ph=tk.Frame(self.ptile,bg=C["dim"]); ph.pack(fill="x",padx=10,pady=8)
        tk.Label(ph,text="📱  PHONE",font=fmono(7,True),bg=C["dim"],fg=C["muted"]).pack(anchor="w")
        self.lbl_phone=tk.Label(ph,text="Not detected",font=fmono(10,True),bg=C["dim"],fg=C["red"])
        self.lbl_phone.pack(anchor="w",pady=(2,0))
        self.lbl_phone_sub=tk.Label(ph,text="—",font=fmono(8),bg=C["dim"],fg=C["muted"])
        self.lbl_phone_sub.pack(anchor="w")

        tk.Frame(row,bg=C["border2"],width=1).pack(side="left",fill="y")

        self.mtile=tk.Frame(row,bg=C["dim"],highlightbackground=C["border2"],highlightthickness=1)
        self.mtile.pack(side="left",fill="x",expand=True,padx=(8,0))
        mh=tk.Frame(self.mtile,bg=C["dim"]); mh.pack(fill="x",padx=10,pady=8)
        tk.Label(mh,text="🖥️  MEmu EMULATOR",font=fmono(7,True),bg=C["dim"],fg=C["muted"]).pack(anchor="w")
        self.lbl_memu=tk.Label(mh,text="Not detected",font=fmono(10,True),bg=C["dim"],fg=C["red"])
        self.lbl_memu.pack(anchor="w",pady=(2,0))
        self.lbl_memu_sub=tk.Label(mh,text="—",font=fmono(8),bg=C["dim"],fg=C["muted"])
        self.lbl_memu_sub.pack(anchor="w")

        sr=tk.Frame(card,bg=C["card"]); sr.pack(fill="x",padx=12,pady=(0,12))
        scan_frame=tk.Frame(sr,bg=C["green"],padx=1,pady=1)
        scan_frame.pack(side="left")
        self.btn_scan=tk.Button(scan_frame,text="⟳   SCAN DEVICES",
            font=fsans(10,True),bg=C["green"],fg=C["hdr"],
            activebackground="#25ee8a",relief="flat",
            padx=22,pady=8,cursor="hand2",command=self._scan)
        self.btn_scan.pack()
        self.lbl_scan_status=tk.Label(sr,text="   Click Scan to detect Phone & MEmu",
            font=fmono(8),bg=C["card"],fg=C["muted"])
        self.lbl_scan_status.pack(side="left",padx=12)

    def _device_info_section(self):
        p2=getattr(self,"_pack_target",self)
        sep=tk.Frame(p2,bg=C["border"],height=1); sep.pack(fill="x",padx=16)
        hrow=tk.Frame(p2,bg=C["bg"]); hrow.pack(fill="x",padx=16,pady=(6,3))
        tk.Frame(hrow,bg=C["blue"],width=3,height=12).pack(side="left",padx=(0,7))
        tk.Label(hrow,text="DEVICE INFORMATION",font=fmono(7,True),bg=C["bg"],fg=C["blue"]).pack(side="left")
        tk.Frame(hrow,bg=C["border"],height=1).pack(side="left",fill="x",expand=True,padx=(10,0))
        p=getattr(self,"_pack_target",self)
        self.info_outer=tk.Frame(p,bg=C["card"],highlightbackground=C["border"],highlightthickness=1)
        self.info_outer.pack(fill="x",padx=16,pady=(0,4))
        self.info_content=tk.Frame(self.info_outer,bg=C["card"])
        self.info_content.pack(fill="x",padx=8,pady=8)
        tk.Label(self.info_content,
            text="  Scan devices to load phone details here  ",
            font=fmono(8),bg=C["card"],fg=C["muted"],pady=12).pack(anchor="w")

    def _show_phone_info(self, info):
        # Destroy old placeholder content
        for widget in self.info_outer.winfo_children():
            widget.destroy()

        # Rebuild info_content fresh inside info_outer
        self.info_content = tk.Frame(self.info_outer, bg=C["card"])
        self.info_content.pack(fill="x", padx=8, pady=8)

        ICONS = {"Full Name":"📱", "Model No":"🔖", "Serial No":"🔢",
                 "IMEI 1":"📡", "IMEI 2":"📡"}

        items = list(info.items())

        # Single row of equal-width cells using pack
        row_frame = tk.Frame(self.info_content, bg=C["card"])
        row_frame.pack(fill="x", pady=4)

        for key, val in items:
            hl   = key in {"IMEI 1", "IMEI 2"}
            acc  = C["accent"] if hl else C["blue"]
            icon = ICONS.get(key, "•")

            cell = tk.Frame(row_frame, bg=C["dim"],
                            highlightbackground=C["accent"] if hl else C["border2"],
                            highlightthickness=1)
            cell.pack(side="left", fill="both", expand=True, padx=4)

            tk.Label(cell,
                     text=f"{icon}  {key.upper()}",
                     font=fmono(6, True), bg=C["dim"], fg=acc,
                     padx=12, pady=2).pack(anchor="w", pady=(8, 0))

            val_color = C["accent"] if hl else C["text"]
            val_font  = fmono(10, True) if hl else fmono(9, True)
            tk.Label(cell,
                     text=val or "N/A",
                     font=val_font, bg=C["dim"], fg=val_color,
                     wraplength=160, justify="left",
                     padx=12, pady=4).pack(anchor="w", pady=(0, 10))

        # Defer canvas scroll-region update to AFTER tkinter finishes drawing
        def _refresh_canvas():
            c = self._tab_wa["canvas"]
            c.configure(scrollregion=c.bbox("all"))

        self.after(50,  _refresh_canvas)
        self.after(200, _refresh_canvas)

    def _source_section(self):
        self._sec("SOURCE PATH  (Phone)")
        card = self._card()
        row  = tk.Frame(card, bg=C["card"])
        row.pack(fill="x", padx=12, pady=10)

        self.source_var = tk.StringVar(value="")

        self.lbl_source_path = tk.Label(row,
            text="  No source selected — Click Browse ADB",
            font=fmono(9), bg=C["dim"], fg=C["muted"],
            anchor="w", padx=10, pady=7)
        self.lbl_source_path.pack(side="left", fill="x", expand=True, padx=(0,10))

        tk.Button(row, text="✕  Clear",
            font=fmono(8), bg=C["dim"], fg=C["muted"],
            activebackground=C["border"], relief="flat",
            padx=10, pady=7, cursor="hand2",
            command=self._clear_source).pack(side="right", padx=(4,0))

        tk.Button(row, text="📂  Browse ADB",
            font=fsans(10,True), bg=C["blue"], fg="white",
            activebackground="#3b72d9", relief="flat",
            padx=16, pady=7, cursor="hand2",
            command=self._browse_source).pack(side="right")

    def _browse_source(self):
        if not self.phone_id:
            messagebox.showwarning("No Phone", "Please scan devices first.")
            return
        current = self.source_var.get().strip().rstrip("/")
        win = tk.Toplevel(self)
        win.title("Browse Phone — ADB")
        win.geometry("620x460")
        win.configure(bg=C["bg"])
        win.grab_set()

        tk.Label(win, text="BROWSE PHONE STORAGE",
                 font=fmono(8,True), bg=C["bg"], fg=C["accent"]).pack(pady=(12,4))

        path_var = tk.StringVar(value=current or "/sdcard")
        path_row = tk.Frame(win, bg=C["bg"]); path_row.pack(fill="x",padx=12,pady=4)
        path_entry = tk.Entry(path_row, textvariable=path_var,
                              font=fmono(9), bg=C["dim"], fg=C["text"],
                              insertbackground=C["accent"], relief="flat")
        path_entry.pack(side="left", fill="x", expand=True, ipady=6, padx=(0,6))
        tk.Button(path_row, text="Go", font=fmono(9,True),
                  bg=C["blue"], fg="white", relief="flat", padx=12, pady=4,
                  command=lambda: _load(path_var.get().strip())).pack(side="left")

        listbox = tk.Listbox(win, font=fmono(10), bg=C["dim"], fg=C["text"],
                             selectbackground=C["accent"], selectforeground=C["hdr"],
                             relief="flat", bd=0, activestyle="none")
        listbox.pack(fill="both", expand=True, padx=12, pady=6)

        status = tk.Label(win, text="Loading...", font=fmono(7),
                          bg=C["bg"], fg=C["muted"])
        status.pack(pady=(0,4))

        btn_row = tk.Frame(win, bg=C["bg"]); btn_row.pack(pady=8)
        tk.Button(btn_row, text="⬆  Up", font=fmono(9,True),
                  bg=C["dim"], fg=C["sub"], relief="flat", padx=14, pady=6,
                  command=lambda: _go_up()).pack(side="left", padx=4)
        tk.Button(btn_row, text="✓  Select This Folder", font=fsans(10,True),
                  bg=C["green"], fg=C["hdr"], relief="flat", padx=18, pady=6,
                  command=lambda: _select()).pack(side="left", padx=4)
        tk.Button(btn_row, text="✕  Cancel", font=fmono(9),
                  bg=C["red"], fg="white", relief="flat", padx=14, pady=6,
                  command=win.destroy).pack(side="left", padx=4)

        def _load(path):
            path = path.rstrip("/") or "/sdcard"
            path_var.set(path)
            listbox.delete(0,"end")
            listbox.insert("end","  ⏳  Loading…")
            status.config(text="Loading…", fg=C["muted"])
            win.update_idletasks()
            def _do():
                out, _, _ = run_adb(
                    ["shell", "ls", "-la", path + "/"],
                    device=self.phone_id)
                dirs = []
                if out:
                    for line in out.splitlines():
                        parts = line.split()
                        if parts and parts[0].startswith("d"):
                            name = parts[-1]
                            if name not in (".", ".."):
                                dirs.append(name)
                if not dirs:
                    out2, _, _ = run_adb(
                        ["shell", "ls", path + "/"],
                        device=self.phone_id)
                    if out2:
                        for name in out2.splitlines():
                            name = name.strip()
                            if name and not name.startswith("ls:"):
                                _, _, rc = run_adb(
                                    ["shell", "test", "-d",
                                     f"{path}/{name}"],
                                    device=self.phone_id)
                                if rc == 0:
                                    dirs.append(name)
                win.after(0, lambda d=dirs, p=path: _populate(d, p))
            threading.Thread(target=_do, daemon=True).start()

        def _populate(dirs, path):
            listbox.delete(0,"end")
            if not dirs:
                listbox.insert("end","  (no subfolders found)")
                status.config(text=f"Path: {path}  |  No subfolders", fg=C["muted"])
            else:
                for d in sorted(dirs):
                    listbox.insert("end", f"  📁  {d}")
                status.config(text=f"Path: {path}  |  {len(dirs)} folder(s)", fg=C["sub"])

        def _go_up():
            p = path_var.get().rstrip("/")
            parent = "/".join(p.split("/")[:-1]) or "/"
            _load(parent)

        def _on_double(e):
            sel = listbox.curselection()
            if sel:
                name = listbox.get(sel[0]).strip().lstrip("📁").strip()
                _load(f"{path_var.get().rstrip('/')}/{name}")
        listbox.bind("<Double-Button-1>", _on_double)

        def _select():
            path = path_var.get().rstrip("/") + "/"
            self.source_var.set(path)
            self.lbl_source_path.config(text=f"  {path}", fg=C["green"])
            self._log(f"Source path → {path}", "ok")
            win.destroy()

        _load(path_var.get())

    def _clear_source(self):
        self.source_var.set("")
        self.lbl_source_path.config(
            text="  No source selected — Click Browse ADB",
            fg=C["muted"])
        self._log("Source path cleared", "warn")

    def _folder_section(self):
        self._sec("BACKUP DESTINATION")
        card=self._card()
        row=tk.Frame(card,bg=C["card"]); row.pack(fill="x",padx=12,pady=10)
        self.lbl_path=tk.Label(row,text="  No folder selected — Click BROWSE",
            font=fmono(9),bg=C["dim"],fg=C["muted"],anchor="w",padx=10,pady=7)
        self.lbl_path.pack(side="left",fill="x",expand=True,padx=(0,10))
        tk.Button(row,text="✕  Clear",font=fmono(8),bg=C["dim"],fg=C["muted"],
            activebackground=C["border"],relief="flat",padx=10,pady=7,cursor="hand2",
            command=self._clear_folder).pack(side="right",padx=(6,0))
        tk.Button(row,text="📂   BROWSE",font=fsans(10,True),bg=C["blue"],fg="white",
            activebackground="#3b72d9",relief="flat",padx=16,pady=7,cursor="hand2",
            command=self._browse_folder).pack(side="right")

    def _action_row(self):
        p=getattr(self,"_pack_target",self)
        row=tk.Frame(p,bg=C["bg"]); row.pack(fill="x",padx=16,pady=12)

        start_frame=tk.Frame(row,bg=C["blue"],padx=2,pady=2)
        start_frame.pack(side="left",padx=(0,10))
        self.btn_backup=tk.Button(start_frame,text="▶   START BACKUP",
            font=fsans(11,True),bg=C["blue"],fg="white",
            activebackground="#5a9eff",relief="flat",
            padx=26,pady=10,cursor="hand2",state="disabled",
            command=self._start_backup)
        self.btn_backup.pack()

        tk.Button(row,text="⌫  CLEAR LOG",font=fmono(9,True),
            bg=C["dim"],fg=C["sub"],activebackground=C["border2"],
            relief="flat",padx=16,pady=10,cursor="hand2",
            command=self._clear_log).pack(side="left",padx=(0,10))

        cancel_frame=tk.Frame(row,bg=C["red"],padx=1,pady=1)
        cancel_frame.pack(side="left")
        self.btn_cancel=tk.Button(cancel_frame,text="✕  CANCEL",
            font=fmono(9,True),bg=C["red"],fg="white",
            activebackground="#ff5577",relief="flat",
            padx=16,pady=10,cursor="hand2",state="disabled",
            command=self._cancel_backup)
        self.btn_cancel.pack()

    def _progress_section(self):
        card=self._card()
        pw=tk.Frame(card,bg=C["card"]); pw.pack(fill="x",padx=12,pady=(10,6))
        style=ttk.Style(); style.theme_use("default")
        style.configure("Pro.Horizontal.TProgressbar",
            troughcolor=C["dim"], background=C["accent"],
            thickness=14, bordercolor=C["border2"],
            lightcolor=C["accent"], darkcolor=C["accent2"])
        self.pb=ttk.Progressbar(pw,mode="determinate",maximum=100,value=0,
            style="Pro.Horizontal.TProgressbar")
        self.pb.pack(fill="x", pady=(4,0))
        sr=tk.Frame(card,bg=C["card"]); sr.pack(fill="x",padx=12,pady=(0,10))

        def _stat_box(parent, label, init, color, side="left"):
            f=tk.Frame(parent,bg=C["dim"],
                       highlightbackground=C["border2"],highlightthickness=1)
            f.pack(side=side,padx=(0,6),pady=4)
            tk.Label(f,text=label,font=fmono(6,True),
                     bg=C["dim"],fg=C["muted"],padx=14,pady=4).pack(anchor="w",pady=(6,0))
            lbl=tk.Label(f,text=init,font=fmono(13,True),
                         bg=C["dim"],fg=color,padx=14,pady=6)
            lbl.pack(anchor="w",pady=(2,8))
            return lbl

        self.lbl_speed   = _stat_box(sr,"⚡ SPEED",  "— MB/s", C["accent"])
        self.lbl_elapsed = _stat_box(sr,"⏱ ELAPSED", "00:00",  C["blue"])
        self.lbl_pct     = _stat_box(sr,"📊 PROGRESS","0%",     C["amber"])

    def _console_section(self):
        self._sec("CONSOLE OUTPUT")
        p=getattr(self,"_pack_target",self)
        con_outer=tk.Frame(p,bg=C["accent"],padx=1,pady=0)
        con_outer.pack(fill="both",expand=True,padx=16,pady=(2,8))
        tk.Frame(con_outer,bg=C["accent"],height=2).pack(fill="x")
        self.log=scrolledtext.ScrolledText(con_outer,font=fmono(9),
            bg="#060a16",fg=C["text"],
            insertbackground=C["accent"],relief="flat",bd=0,
            state="disabled", selectbackground=C["border2"],
            height=12, padx=10, pady=8)
        self.log.pack(fill="both",expand=True)
        self.log.tag_config("ok",   foreground=C["green"])
        self.log.tag_config("err",  foreground=C["red"])
        self.log.tag_config("warn", foreground=C["amber"])
        self.log.tag_config("info", foreground=C["accent2"])
        self.log.tag_config("head", foreground=C["accent"],
                            font=fmono(9,True))
        self.log.tag_config("dim",  foreground=C["muted"])
        self.log.tag_config("ts",   foreground="#2a3a5a")

    def _footer(self):
        p=getattr(self,"_pack_target",self)
        foot=tk.Frame(p,bg=C["hdr"])
        foot.pack(fill="x",pady=(8,0))
        bar=tk.Frame(foot,bg=C["hdr"],height=2)
        bar.pack(fill="x")
        for col,w in [(C["accent"],150),(C["accent2"],100),(C["blue"],100),
                      (C["border"],2000)]:
            tk.Frame(bar,bg=col,height=2,width=w).pack(side="left")
        txt_row=tk.Frame(foot,bg=C["hdr"])
        txt_row.pack(fill="x",padx=16,pady=6)
        tk.Label(txt_row,text="🔌  USB Debugging ON",
                 font=fmono(7),bg=C["hdr"],fg=C["muted"]).pack(side="left",padx=(0,16))
        tk.Label(txt_row,text="🖥️  MEmu fully loaded",
                 font=fmono(7),bg=C["hdr"],fg=C["muted"]).pack(side="left",padx=(0,16))
        tk.Label(txt_row,text="DataBridge PRO v3.0  © 2026 Venu Gopal Bathula",
                 font=fmono(7,True),bg=C["hdr"],fg=C["border2"]).pack(side="right")

    def _log(self,msg,tag="info"):
        self.log.config(state="normal")
        ts=datetime.now().strftime("%H:%M:%S")
        self.log.insert("end",f"[{ts}] ","ts")
        self.log.insert("end",msg+"\n",tag)
        self.log.see("end")
        self.log.config(state="disabled")

    def _clear_log(self):
        self.log.config(state="normal"); self.log.delete("1.0","end"); self.log.config(state="disabled")

    def _browse_folder(self):
        folder=filedialog.askdirectory(title="Select Backup Destination",initialdir=os.path.expanduser("~"))
        if folder:
            self.selected_folder=folder
            self.lbl_path.config(text=f"  {folder}",fg=C["green"])
            self._log(f"Backup folder → {folder}","ok")
            if self.phone_id and self.memu_id: self.btn_backup.config(state="normal")

    def _clear_folder(self):
        self.selected_folder=None
        self.lbl_path.config(text="  No folder selected — Click BROWSE",fg=C["muted"])
        self.btn_backup.config(state="disabled"); self._log("Folder cleared","warn")

    def _scan(self):
        self.lbl_scan_status.config(text="   Scanning…",fg=C["amber"])
        self.btn_scan.config(state="disabled")
        self._log("━"*54,"head"); self._log("Scanning ADB devices…","info")
        threading.Thread(target=self._do_scan,daemon=True).start()

    def _do_scan(self):
        stdout,_,_=run_adb(["devices"])
        devs=[l.split()[0] for l in stdout.splitlines()[1:] if "device" in l and "offline" not in l]
        self.phone_id=next((d for d in devs if "." not in d and not d.startswith("emulator")),None)
        self.memu_id =next((d for d in devs if "127.0.0.1" in d or d.startswith("emulator")),None)
        def ui():
            self.lbl_phone.config(text=self.phone_id or "Not detected",
                fg=C["green"] if self.phone_id else C["red"])
            self.lbl_memu.config(text=self.memu_id or "Not detected",
                fg=C["green"] if self.memu_id else C["red"])
            if self.phone_id: self.lbl_phone_sub.config(text="USB connected  •  ADB authorized",fg=C["sub"])
            if self.memu_id:  self.lbl_memu_sub.config(text="Emulator running  •  ADB connected",fg=C["sub"])
            self._log(f"Phone  →  {self.phone_id or 'Not found'}","ok" if self.phone_id else "err")
            self._log(f"MEmu   →  {self.memu_id  or 'Not found'}","ok" if self.memu_id  else "err")
            if self.phone_id and self.memu_id:
                if self.selected_folder: self.btn_backup.config(state="normal")
                self.lbl_scan_status.config(text="   ✓  Both devices ready!",fg=C["green"])
                self._log("Both detected — fetching device info…","ok")
                threading.Thread(target=self._fetch_info,daemon=True).start()
            else:
                self.btn_backup.config(state="disabled")
                self.lbl_scan_status.config(text="   ⚠  Connect phone + open MEmu, then scan again",fg=C["amber"])
            self.btn_scan.config(state="normal")
        self.after(0,ui)

    def _fetch_info(self):
        try:
            info=get_phone_info(self.phone_id)
        except Exception as e:
            self.after(0,lambda: self._log(f"Device info error: {e}","err"))
            return
        name   = info.get("Full Name","")
        model  = info.get("Model No","")
        serial = info.get("Serial No","")
        imei1  = info.get("IMEI 1","")
        self.after(0,lambda i=info: self._show_phone_info(i))
        self.after(100,lambda: self.lbl_phone_sub.config(
            text=f"{name}  •  S/N: {serial}",fg=C["sub"]))
        self.after(200,lambda: self._log(
            f"Device: {name}  |  Model: {model}  |  S/N: {serial}  |  IMEI: {imei1}","ok"))

    def _start_backup(self):
        if not self.selected_folder:
            messagebox.showwarning("No Folder","Please select a backup destination folder first.")
            return
        self._cancel_flag=False; self._backup_folder=self.selected_folder
        src = self.source_var.get().strip()
        self._source_path = src if src.endswith("/") else src + "/"
        self.btn_backup.config(state="disabled"); self.btn_cancel.config(state="normal")
        self.pb["value"]=0; self.lbl_pct.config(text="0%")
        self.lbl_speed.config(text="— MB/s",fg=C["accent"])
        self.lbl_elapsed.config(text="00:00",fg=C["blue"])
        self._start_time=time.time(); self._timer_running=True
        threading.Thread(target=self._update_timer,daemon=True).start()
        threading.Thread(target=self._run_backup,   daemon=True).start()

    def _cancel_backup(self):
        if messagebox.askyesno("Cancel Backup","Cancel the ongoing backup?"):
            self._cancel_flag=True; self._timer_running=False; self._speed_running=False
            self._log("BACKUP CANCELLED BY USER","err"); self._set_progress(0)
            self.lbl_elapsed.config(text="cancelled",fg=C["red"])
            self.btn_cancel.config(state="disabled"); self.btn_backup.config(state="normal")

    def _update_timer(self):
        while self._timer_running:
            e=int(time.time()-self._start_time); m,s=divmod(e,60)
            self.after(0,lambda m=m,s=s: self.lbl_elapsed.config(text=f"{m:02d}:{s:02d}",fg=C["blue"]))
            time.sleep(1)

    def _start_speed_monitor(self,path):
        self._speed_running=True
        def _mon():
            prev,pt=0,time.time()
            while self._speed_running:
                time.sleep(1)
                try:
                    cur=folder_size(path); ct=time.time()
                    db,dt=cur-prev,ct-pt
                    if dt>0 and db>0:
                        spd=(db/1048576)/dt
                        self.after(0,lambda s=spd: self.lbl_speed.config(text=f"{s:.1f} MB/s",fg=C["accent"]))
                    prev,pt=cur,ct
                except: pass
        threading.Thread(target=_mon,daemon=True).start()

    def _stop_speed_monitor(self): self._speed_running=False

    def _start_device_monitor(self):
        self._device_monitor_running = True
        def _monitor():
            consecutive_fails = 0
            while self._device_monitor_running:
                time.sleep(3)
                if not self._device_monitor_running:
                    break
                out, _, _ = run_adb(["devices"])
                connected = any(
                    self.phone_id in line and "device" in line
                    for line in out.splitlines()
                )
                if not connected:
                    consecutive_fails += 1
                    if consecutive_fails == 1:
                        self.after(0, lambda: self._log(
                            "⚠  WARNING: Phone not detected — checking again…", "warn"))
                    elif consecutive_fails >= 2:
                        self._device_monitor_running = False
                        self._cancel_flag = True
                        self.after(0, self._on_device_disconnected)
                        break
                else:
                    consecutive_fails = 0
        threading.Thread(target=_monitor, daemon=True).start()

    def _stop_device_monitor(self):
        self._device_monitor_running = False

    def _on_device_disconnected(self):
        self._timer_running  = False
        self._speed_running  = False
        self._log("━"*54, "err")
        self._log("🔌  PHONE DISCONNECTED DURING BACKUP!", "err")
        self._log("   The backup process was interrupted.", "err")
        self._log("   Please reconnect the phone and try again.", "warn")
        self._log("━"*54, "err")
        self.lbl_speed.config(text="Disconnected!", fg=C["red"])
        self.btn_backup.config(state="normal")
        self.btn_cancel.config(state="disabled")
        self.lbl_phone.config(text="📵  DISCONNECTED", fg=C["red"])
        self.lbl_phone_sub.config(text="Phone lost during backup — reconnect USB", fg=C["red"])
        messagebox.showerror("📵  Phone Disconnected!",
            "The phone was disconnected during backup!\n\n"
            "The backup is INCOMPLETE.\n"
            "Please reconnect the USB cable and start again.")

    def _set_progress(self,v):
        self.after(0,lambda: self.pb.config(value=v))
        self.after(0,lambda: self.lbl_pct.config(text=f"{int(v)}%"))

    def _push_subfolders(self, wa_local, memu_dest, label=""):
        SUBS = ["Backups", "Databases", "Media"]
        for sub in SUBS:
            if self._cancel_flag: return False
            local_sub = os.path.join(wa_local, sub)
            if not os.path.exists(local_sub):
                self._log(f"  ⚠  {label}{sub} not found — skipping", "warn")
                continue
            self._log(f"  → Pushing  {label}{sub}…", "info")
            run_adb(["shell","rm","-rf",f"{memu_dest}/{sub}"], device=self.memu_id)
            run_adb(["shell","mkdir","-p", memu_dest],          device=self.memu_id)
            self._start_speed_monitor(local_sub)
            ts = time.time()
            _, err, code = run_adb_priority(
                ["push", local_sub, f"{memu_dest}/{sub}"],
                device=self.memu_id)
            elapsed = time.time() - ts
            self._stop_speed_monitor()
            if code == 0:
                self._log(f"  ✓  {label}{sub} — Done!  ({elapsed:.1f}s)", "ok")
            else:
                self._log(f"  ✗  {label}{sub} failed: {err}", "err")
        return True

    def _run_backup(self):
        try:
            self._log("━"*54,"head"); self._log("▶  BACKUP STARTED","head"); self._log("━"*54,"head")
            os.makedirs(self._backup_folder, exist_ok=True)

            self._log("\n[ STEP 1 / 3 ]  Pulling entire WhatsApp folder from phone…","info")
            self._log(f"  Save to : {self._backup_folder}","dim")
            self._set_progress(5)
            self._start_speed_monitor(self._backup_folder)
            t1 = time.time()
            src = self._source_path
            self._log(f"  Source  : {src}", "dim")
            _, err, code = run_adb_priority(
                ["pull", src, self._backup_folder],
                device=self.phone_id)
            pull_time = time.time() - t1
            self._stop_speed_monitor()
            if self._cancel_flag: return
            if code == 0:
                self._log(f"  ✓  Done!  ({pull_time:.1f}s)", "ok")
                self._set_progress(40)
            else:
                self._log(f"  ✗  Pull failed: {err}", "err"); return

            wa_local = os.path.join(self._backup_folder, "WhatsApp")
            if not os.path.exists(wa_local):
                self._log("  ✗  WhatsApp folder not found in backup", "err"); return

            self._log(f"\n[ STEP 2 / 3 ]  Pushing to MEmu…","info")
            self._set_progress(45)

            accounts_local = os.path.join(wa_local, "accounts")
            has_accounts   = os.path.exists(accounts_local) and os.path.isdir(accounts_local)
            account_ids    = sorted(os.listdir(accounts_local)) if has_accounts else []

            if has_accounts and account_ids:
                self._log(f"  📱  Found {len(account_ids)} WhatsApp account(s): {', '.join(account_ids)}", "ok")
                self._log(f"\n  ── Main Account ──", "info")
                self._log(f"  Destination : {MEMU_DEST}", "dim")
                self._push_subfolders(wa_local, MEMU_DEST, label="")
                self._set_progress(65)

                total_acc  = len(account_ids)
                for idx, acc_id in enumerate(account_ids):
                    if self._cancel_flag: return
                    acc_local = os.path.join(accounts_local, acc_id)
                    acc_memu  = f"{MEMU_ACCOUNTS}/{acc_id}"
                    self._log(f"\n  ── Account {acc_id} ──", "info")
                    self._log(f"  Destination : {acc_memu}", "dim")
                    run_adb(["shell","mkdir","-p", acc_memu], device=self.memu_id)
                    self._push_subfolders(acc_local, acc_memu, label=f"[{acc_id}] ")
                    prog = 65 + int((idx+1) / total_acc * 23)
                    self._set_progress(prog)
            else:
                self._log(f"  Destination : {MEMU_DEST}", "dim")
                self._push_subfolders(wa_local, MEMU_DEST)
                self._set_progress(88)

            if self._cancel_flag: return
            self._set_progress(90)

            self._log(f"\n[ STEP 3 / 3 ]  Verifying in MEmu…","info")
            stdout,_,_ = run_adb(["shell","ls",MEMU_DEST], device=self.memu_id)
            if stdout:
                self._log("  ✓  MEmu WhatsApp contents:","ok")
                for line in stdout.splitlines()[:8]:
                    self._log(f"     📁  {line}","dim")
            self._set_progress(100)
            self._timer_running = False
            self.after(0, lambda: self.lbl_speed.config(text="Done!", fg=C["green"]))

            total = int(time.time()-self._start_time)
            m, s  = divmod(total, 60)
            ts_str = f"{m}m {s}s" if m else f"{s}s"
            acc_info = f"{len(account_ids)} sub-account(s)" if has_accounts and account_ids else "Single account"
            self._log("\n"+"━"*54,"head")
            self._log("🎉  BACKUP COMPLETE!","head")
            self._log(f"  ⏱  Time     : {ts_str}","ok")
            self._log(f"  📱  Accounts : {acc_info}","ok")
            self._log(f"  💾  Saved    : {self._backup_folder}","ok")
            self._log(f"  📁  MEmu     : {MEMU_DEST}","ok")
            self._log("━"*54,"head")
            msg = (f"Backup finished!\n\n"
                   f"\u23f1  Time     : {ts_str}\n"
                   f"\U0001f4f1  Accounts : {acc_info}\n"
                   f"\U0001f4be  Saved    : {self._backup_folder}\n"
                   f"\U0001f4c1  MEmu     : {MEMU_DEST}")
            self.after(0,lambda m=msg: messagebox.showinfo("Backup Complete!", m))
        except Exception as e:
            self._log(f"  ✗  Unexpected error: {e}","err")
        finally:
            self._timer_running=False; self._speed_running=False
            self._stop_device_monitor()
            self.after(0,lambda: self.btn_backup.config(state="normal"))
            self.after(0,lambda: self.btn_cancel.config(state="disabled"))

    # ═══════════════════════════════════════════════════════════
    #  PC / HDD TRANSFER TAB
    # ═══════════════════════════════════════════════════════════
    def _pc_transfer_tab(self):
        p = self._pack_target

        # ── Header banner ──────────────────────────────────────
        banner = tk.Frame(p, bg=C["orange"], padx=2, pady=2)
        banner.pack(fill="x", padx=16, pady=(14,4))
        tk.Label(banner,
            text="💾  PC / HARD DISK TRANSFER  —  Copy files between PC, USB drives & external HDDs",
            font=fsans(9,True), bg=C["orange"], fg=C["hdr"],
            padx=14, pady=8).pack(anchor="w")

        # ── Drive info row ─────────────────────────────────────
        self._pt_sec("DETECTED DRIVES")
        dcard = self._pt_card()
        drow  = tk.Frame(dcard, bg=C["card"]); drow.pack(fill="x", padx=12, pady=8)
        tk.Button(drow, text="⟳  REFRESH DRIVES",
            font=fsans(9,True), bg=C["green"], fg=C["hdr"],
            relief="flat", padx=16, pady=6, cursor="hand2",
            command=self._pt_refresh_drives).pack(side="left")
        self.lbl_pt_drives = tk.Label(drow,
            text="   Click Refresh to detect drives",
            font=fmono(8), bg=C["card"], fg=C["muted"])
        self.lbl_pt_drives.pack(side="left", padx=12)

        # ── Source ─────────────────────────────────────────────
        self._pt_sec("SOURCE  (Copy FROM)")
        scard = self._pt_card()
        srow  = tk.Frame(scard, bg=C["card"]); srow.pack(fill="x", padx=12, pady=10)
        self.lbl_pt_src = tk.Label(srow,
            text="  No source selected",
            font=fmono(9), bg=C["dim"], fg=C["muted"], anchor="w", padx=10, pady=7)
        self.lbl_pt_src.pack(side="left", fill="x", expand=True, padx=(0,10))
        tk.Button(srow, text="✕ Clear", font=fmono(8), bg=C["dim"], fg=C["muted"],
            relief="flat", padx=8, pady=7, cursor="hand2",
            command=lambda: self._pt_clear("src")).pack(side="right", padx=(4,0))
        tk.Button(srow, text="📂  Browse Source",
            font=fsans(10,True), bg=C["blue"], fg="white",
            relief="flat", padx=14, pady=7, cursor="hand2",
            command=lambda: self._pt_browse("src")).pack(side="right")

        # Source info
        self.lbl_pt_src_info = tk.Label(scard,
            text="", font=fmono(7), bg=C["card"], fg=C["sub"])
        self.lbl_pt_src_info.pack(anchor="w", padx=22, pady=(0,8))

        # ── Destination ────────────────────────────────────────
        self._pt_sec("DESTINATION  (Copy TO)")
        dstcard = self._pt_card()
        dstrow  = tk.Frame(dstcard, bg=C["card"]); dstrow.pack(fill="x", padx=12, pady=10)
        self.lbl_pt_dst = tk.Label(dstrow,
            text="  No destination selected",
            font=fmono(9), bg=C["dim"], fg=C["muted"], anchor="w", padx=10, pady=7)
        self.lbl_pt_dst.pack(side="left", fill="x", expand=True, padx=(0,10))
        tk.Button(dstrow, text="✕ Clear", font=fmono(8), bg=C["dim"], fg=C["muted"],
            relief="flat", padx=8, pady=7, cursor="hand2",
            command=lambda: self._pt_clear("dst")).pack(side="right", padx=(4,0))
        tk.Button(dstrow, text="📂  Browse Destination",
            font=fsans(10,True), bg=C["blue"], fg="white",
            relief="flat", padx=14, pady=7, cursor="hand2",
            command=lambda: self._pt_browse("dst")).pack(side="right")

        self.lbl_pt_dst_info = tk.Label(dstcard,
            text="", font=fmono(7), bg=C["card"], fg=C["sub"])
        self.lbl_pt_dst_info.pack(anchor="w", padx=22, pady=(0,8))

        # ── Options ────────────────────────────────────────────
        self._pt_sec("OPTIONS")
        ocard = self._pt_card()
        orow  = tk.Frame(ocard, bg=C["card"]); orow.pack(fill="x", padx=12, pady=10)

        self._pt_opt_verify = tk.BooleanVar(value=True)

        tk.Checkbutton(orow, text="✅ Verify after copy",
            variable=self._pt_opt_verify,
            font=fsans(9,True), bg=C["card"], fg=C["green"],
            selectcolor=C["dim"], activebackground=C["card"],
            activeforeground=C["green"], cursor="hand2").pack(side="left", padx=12)

        tk.Label(orow,
            text="  Copies ALL files and subfolders exactly as they are",
            font=fmono(8), bg=C["card"], fg=C["muted"]).pack(side="left", padx=8)

        # ── Action buttons ─────────────────────────────────────
        p2 = self._pack_target
        arow = tk.Frame(p2, bg=C["bg"]); arow.pack(fill="x", padx=16, pady=12)

        start_f = tk.Frame(arow, bg=C["orange"], padx=2, pady=2)
        start_f.pack(side="left", padx=(0,10))
        self.btn_pt_start = tk.Button(start_f, text="▶  START TRANSFER",
            font=fsans(11,True), bg=C["orange"], fg=C["hdr"],
            activebackground="#ff9d5c", relief="flat",
            padx=26, pady=10, cursor="hand2",
            command=self._pt_start)
        self.btn_pt_start.pack()

        tk.Button(arow, text="⌫  CLEAR LOG",
            font=fmono(9,True), bg=C["dim"], fg=C["sub"],
            activebackground=C["border2"], relief="flat",
            padx=16, pady=10, cursor="hand2",
            command=self._pt_clear_log).pack(side="left", padx=(0,10))

        cancel_f = tk.Frame(arow, bg=C["red"], padx=1, pady=1)
        cancel_f.pack(side="left")
        self.btn_pt_cancel = tk.Button(cancel_f, text="✕  CANCEL",
            font=fmono(9,True), bg=C["red"], fg="white",
            activebackground="#ff5577", relief="flat",
            padx=16, pady=10, cursor="hand2", state="disabled",
            command=self._pt_cancel)
        self.btn_pt_cancel.pack()

        # ── Progress ───────────────────────────────────────────
        pcard = self._pt_card()
        pw = tk.Frame(pcard, bg=C["card"]); pw.pack(fill="x", padx=12, pady=(10,4))

        style = ttk.Style()
        style.configure("PT.Horizontal.TProgressbar",
            troughcolor=C["dim"], background=C["orange"],
            thickness=14, bordercolor=C["border2"],
            lightcolor=C["orange"], darkcolor="#cc5500")
        self.pt_pb = ttk.Progressbar(pw, mode="determinate",
            maximum=100, value=0, style="PT.Horizontal.TProgressbar")
        self.pt_pb.pack(fill="x", pady=(4,0))

        sr = tk.Frame(pcard, bg=C["card"]); sr.pack(fill="x", padx=12, pady=(0,10))

        def _stat(parent, label, init, color):
            f = tk.Frame(parent, bg=C["dim"],
                highlightbackground=C["border2"], highlightthickness=1)
            f.pack(side="left", padx=(0,6), pady=4)
            tk.Label(f, text=label, font=fmono(6,True),
                bg=C["dim"], fg=C["muted"], padx=14, pady=4).pack(anchor="w", pady=(6,0))
            lbl = tk.Label(f, text=init, font=fmono(13,True),
                bg=C["dim"], fg=color, padx=14, pady=6)
            lbl.pack(anchor="w", pady=(2,8))
            return lbl

        self.lbl_pt_speed   = _stat(sr, "⚡ SPEED",    "— MB/s", C["orange"])
        self.lbl_pt_elapsed = _stat(sr, "⏱ ELAPSED",  "00:00",  C["blue"])
        self.lbl_pt_pct     = _stat(sr, "📊 PROGRESS", "0%",     C["amber"])
        self.lbl_pt_files   = _stat(sr, "📁 FILES",    "0 / 0",  C["green"])

        # ── Console ────────────────────────────────────────────
        self._pt_sec("TRANSFER LOG")
        p3 = self._pack_target
        con_outer = tk.Frame(p3, bg=C["orange"], padx=1, pady=0)
        con_outer.pack(fill="both", expand=True, padx=16, pady=(2,16))
        tk.Frame(con_outer, bg=C["orange"], height=2).pack(fill="x")
        self.pt_log = scrolledtext.ScrolledText(con_outer, font=fmono(9),
            bg="#060a16", fg=C["text"], insertbackground=C["orange"],
            relief="flat", bd=0, state="disabled",
            selectbackground=C["border2"], height=12, padx=10, pady=8)
        self.pt_log.pack(fill="both", expand=True)
        for tag, color in [("ok",C["green"]),("err",C["red"]),("warn",C["amber"]),
                           ("info",C["accent2"]),("head",C["orange"]),
                           ("dim",C["muted"]),("ts","#2a3a5a")]:
            self.pt_log.tag_config(tag, foreground=color)
        self.pt_log.tag_config("head", font=fmono(9,True))

    # ── PC Transfer helpers ────────────────────────────────────
    def _pt_sec(self, text):
        p = getattr(self,"_pack_target",self)
        row = tk.Frame(p, bg=C["bg"]); row.pack(fill="x", padx=16, pady=(12,4))
        tk.Frame(row, bg=C["orange"], width=3, height=14).pack(side="left", padx=(0,8))
        tk.Label(row, text=text, font=fmono(7,True), bg=C["bg"],
                 fg=C["orange"]).pack(side="left")
        tk.Frame(row, bg=C["border2"], height=1).pack(
            side="left", fill="x", expand=True, padx=(12,0))

    def _pt_card(self):
        p = getattr(self,"_pack_target",self)
        outer = tk.Frame(p, bg=C["border2"], padx=1, pady=1)
        outer.pack(fill="x", padx=16, pady=(0,4))
        f = tk.Frame(outer, bg=C["card"]); f.pack(fill="x")
        return f

    def _pt_log(self, msg, tag="info"):
        self.pt_log.config(state="normal")
        ts = datetime.now().strftime("%H:%M:%S")
        self.pt_log.insert("end", f"[{ts}] ", "ts")
        self.pt_log.insert("end", msg+"\n", tag)
        self.pt_log.see("end")
        self.pt_log.config(state="disabled")

    def _pt_clear_log(self):
        self.pt_log.config(state="normal")
        self.pt_log.delete("1.0","end")
        self.pt_log.config(state="disabled")

    def _pt_refresh_drives(self):
        """Detect all drives including USB/external HDDs."""
        drives = []
        if os.name == "nt":
            import string
            for letter in string.ascii_uppercase:
                path = f"{letter}:\\"
                if os.path.exists(path):
                    try:
                        total = 0; free = 0
                        import ctypes
                        free_b  = ctypes.c_ulonglong(0)
                        total_b = ctypes.c_ulonglong(0)
                        ctypes.windll.kernel32.GetDiskFreeSpaceExW(
                            path, None, ctypes.byref(total_b), ctypes.byref(free_b))
                        total = total_b.value; free = free_b.value
                        drives.append(f"{letter}: — {fmt_size(total)} total, {fmt_size(free)} free")
                    except:
                        drives.append(f"{letter}:")
        else:
            import shutil
            for mnt in ["/", "/media", "/mnt"]:
                if os.path.exists(mnt):
                    try:
                        t,u,f = shutil.disk_usage(mnt)
                        drives.append(f"{mnt} — {fmt_size(t)} total, {fmt_size(f)} free")
                    except: pass

        if drives:
            txt = "   " + "   |   ".join(drives[:6])
            self.lbl_pt_drives.config(text=txt, fg=C["green"])
            self._pt_log("Drives detected: " + ", ".join(
                [d.split("—")[0].strip() for d in drives]), "ok")
        else:
            self.lbl_pt_drives.config(text="   No drives found", fg=C["red"])

    def _pt_browse(self, which):
        folder = filedialog.askdirectory(
            title="Select Source Folder" if which=="src" else "Select Destination Folder",
            initialdir=os.path.expanduser("~"))
        if not folder: return
        if which == "src":
            self._pt_src = folder
            self.lbl_pt_src.config(text=f"  {folder}", fg=C["green"])
            # Show folder size
            threading.Thread(target=self._pt_calc_size,
                args=(folder, self.lbl_pt_src_info), daemon=True).start()
            self._pt_log(f"Source → {folder}", "ok")
        else:
            self._pt_dst = folder
            self.lbl_pt_dst.config(text=f"  {folder}", fg=C["green"])
            threading.Thread(target=self._pt_calc_size,
                args=(folder, self.lbl_pt_dst_info), daemon=True).start()
            self._pt_log(f"Destination → {folder}", "ok")

    def _pt_calc_size(self, path, label):
        size = folder_size(path)
        count = sum(len(f) for _,_,f in os.walk(path))
        self.after(0, lambda: label.config(
            text=f"   Size: {fmt_size(size)}  |  Files: {count:,}",
            fg=C["sub"]))

    def _pt_clear(self, which):
        if which == "src":
            self._pt_src = None
            self.lbl_pt_src.config(text="  No source selected", fg=C["muted"])
            self.lbl_pt_src_info.config(text="")
        else:
            self._pt_dst = None
            self.lbl_pt_dst.config(text="  No destination selected", fg=C["muted"])
            self.lbl_pt_dst_info.config(text="")

    def _pt_filter_toggle(self, key):
        """If 'all' toggled on, disable individual filters and vice versa."""
        if key == "all" and self._pt_filter["all"].get():
            for k in ["images","videos","audio","documents"]:
                self._pt_filter[k].set(False)
        elif key != "all":
            self._pt_filter["all"].set(False)

    def _pt_get_extensions(self):
        exts = set()
        if self._pt_filter["all"].get():
            return None  # None = copy all
        if self._pt_filter["images"].get():
            exts |= {".jpg",".jpeg",".png",".gif",".bmp",".webp",
                     ".heic",".heif",".tiff",".raw",".cr2",".nef"}
        if self._pt_filter["videos"].get():
            exts |= {".mp4",".mkv",".avi",".mov",".wmv",".flv",
                     ".3gp",".m4v",".ts",".webm",".mpg",".mpeg"}
        if self._pt_filter["audio"].get():
            exts |= {".mp3",".wav",".flac",".aac",".ogg",".m4a",
                     ".wma",".opus",".aiff"}
        if self._pt_filter["documents"].get():
            exts |= {".pdf",".doc",".docx",".xls",".xlsx",".ppt",
                     ".pptx",".txt",".csv",".zip",".rar",".7z"}
        return exts if exts else None

    def _pt_start(self):
        if not self._pt_src:
            messagebox.showwarning("No Source","Please select a source folder.")
            return
        if not self._pt_dst:
            messagebox.showwarning("No Destination","Please select a destination folder.")
            return
        if os.path.abspath(self._pt_src) == os.path.abspath(self._pt_dst):
            messagebox.showerror("Same Folder","Source and destination cannot be the same folder.")
            return
        self._pt_cancel_flag = False
        self.btn_pt_start.config(state="disabled")
        self.btn_pt_cancel.config(state="normal")
        self.pt_pb["value"] = 0
        self.lbl_pt_pct.config(text="0%")
        self.lbl_pt_speed.config(text="— MB/s", fg=C["orange"])
        self.lbl_pt_elapsed.config(text="00:00", fg=C["blue"])
        self.lbl_pt_files.config(text="0 / 0", fg=C["green"])
        self._pt_start_time = time.time()
        self._pt_timer_running = True
        threading.Thread(target=self._pt_update_timer, daemon=True).start()
        threading.Thread(target=self._pt_run, daemon=True).start()

    def _pt_cancel(self):
        if messagebox.askyesno("Cancel Transfer","Cancel the ongoing transfer?"):
            self._pt_cancel_flag = True
            self._pt_timer_running = False
            self._pt_speed_running = False
            self._pt_log("TRANSFER CANCELLED BY USER","err")
            self.pt_pb["value"] = 0
            self.lbl_pt_elapsed.config(text="cancelled", fg=C["red"])
            self.btn_pt_cancel.config(state="disabled")
            self.btn_pt_start.config(state="normal")

    def _pt_update_timer(self):
        while self._pt_timer_running:
            e = int(time.time()-self._pt_start_time); m,s = divmod(e,60)
            self.after(0, lambda m=m,s=s: self.lbl_pt_elapsed.config(
                text=f"{m:02d}:{s:02d}", fg=C["blue"]))
            time.sleep(1)

    def _pt_run(self):
        try:
            import shutil
            src    = self._pt_src
            dst    = self._pt_dst
            verify = self._pt_opt_verify.get()

            # FIX: Copy entire src FOLDER into dst
            # e.g. src=Desktop/W  dst=Music → result=Music/W/
            src_name   = os.path.basename(src.rstrip("/\\"))
            actual_dst = os.path.join(dst, src_name)

            self._pt_log("━"*52, "head")
            self._pt_log("▶  TRANSFER STARTED", "head")
            self._pt_log(f"  From   : {src}", "dim")
            self._pt_log(f"  To     : {actual_dst}", "dim")
            self._pt_log(f"  Folder : '{src_name}' will be created in destination", "dim")
            self._pt_log("━"*52, "head")

            os.makedirs(actual_dst, exist_ok=True)

            # ── Collect ALL files — including hidden (dot folders) ──
            self._pt_log("\n  Scanning source...", "info")
            all_files = []
            for root, dirs, files in os.walk(src, followlinks=False):
                dirs[:] = [d for d in dirs
                            if os.path.abspath(os.path.join(root, d))
                            != os.path.abspath(dst)]
                for f in files:
                    all_files.append(os.path.join(root, f))

            total_files = len(all_files)
            total_size  = sum(os.path.getsize(f) for f in all_files
                              if os.path.exists(f))

            self._pt_log(f"  Found {total_files:,} files  ({fmt_size(total_size)})", "ok")
            self._pt_log(f"  Destination: {actual_dst}", "dim")

            if total_files == 0:
                self._pt_log("  Source folder is empty. Nothing to copy.", "warn")
                return

            # ── Copy ALL files preserving full structure ───────
            copied = 0; errors = 0; copied_size = 0
            speed_ref_time = time.time()
            speed_ref_size = 0

            for i, fp in enumerate(all_files):
                if self._pt_cancel_flag: break

                rel     = os.path.relpath(fp, src)
                dst_fp  = os.path.join(actual_dst, rel)
                dst_dir = os.path.dirname(dst_fp)

                try:
                    os.makedirs(dst_dir, exist_ok=True)
                    shutil.copy2(fp, dst_fp)
                    file_size    = os.path.getsize(fp)
                    copied      += 1
                    copied_size += file_size

                    now = time.time()
                    if now - speed_ref_time >= 0.5:
                        dt = now - speed_ref_time
                        ds = copied_size - speed_ref_size
                        if dt > 0 and ds > 0:
                            spd = (ds / 1048576) / dt
                            self.after(0, lambda s=spd:
                                self.lbl_pt_speed.config(
                                    text=f"{s:.1f} MB/s", fg=C["orange"]))
                        speed_ref_time = now
                        speed_ref_size = copied_size

                    pct = int((i+1) / total_files * 100)
                    self.after(0, lambda p=pct: self.pt_pb.config(value=p))
                    self.after(0, lambda p=pct: self.lbl_pt_pct.config(text=f"{p}%"))
                    self.after(0, lambda c=copied, t=total_files:
                        self.lbl_pt_files.config(text=f"{c} / {t}", fg=C["green"]))

                    if copied % 50 == 0 or copied <= 5:
                        self._pt_log(f"  ✓  {rel}", "ok")

                except Exception as ex:
                    errors += 1
                    self._pt_log(f"  ✗  {rel}: {ex}", "err")

            # Copy empty folders too
            for root, dirs, files in os.walk(src, followlinks=False):
                for d in dirs:
                    src_d = os.path.join(root, d)
                    rel_d = os.path.relpath(src_d, src)
                    dst_d = os.path.join(actual_dst, rel_d)
                    if not os.path.exists(dst_d):
                        try:
                            os.makedirs(dst_d, exist_ok=True)
                            self._pt_log(f"  📁  {rel_d}  (empty folder)", "dim")
                        except: pass

            if self._pt_cancel_flag:
                return

            # ── Verify ─────────────────────────────────────────
            verify_fail = 0
            if verify and not self._pt_cancel_flag:
                self._pt_log("\n  Verifying copied files...", "info")
                checked = 0
                for fp in all_files:
                    if self._pt_cancel_flag: break
                    rel    = os.path.relpath(fp, src)
                    dst_fp = os.path.join(actual_dst, rel)
                    if os.path.exists(dst_fp):
                        if os.path.getsize(fp) != os.path.getsize(dst_fp):
                            verify_fail += 1
                            self._pt_log(f"  ⚠  Size mismatch: {rel}", "warn")
                    checked += 1
                    if checked % 100 == 0:
                        self._pt_log(f"  Checked {checked}/{total_files}...", "dim")
                if verify_fail == 0:
                    self._pt_log("  ✓  All files verified OK!", "ok")
                else:
                    self._pt_log(f"  ⚠  {verify_fail} files failed verification!", "warn")

            # ── Summary ────────────────────────────────────────
            elapsed = int(time.time()-self._pt_start_time)
            m, s = divmod(elapsed, 60)
            ts_str = f"{m}m {s}s" if m else f"{s}s"

            self._pt_log("\n"+"━"*52, "head")
            self._pt_log("🎉  TRANSFER COMPLETE!", "head")
            self._pt_log(f"  📁  Folder : '{src_name}'  →  {dst}", "ok")
            self._pt_log(f"  ✓  Copied : {copied:,} files ({fmt_size(copied_size)})", "ok")
            if errors:
                self._pt_log(f"  ✗  Errors : {errors}", "err")
            if verify_fail:
                self._pt_log(f"  ⚠  Verify : {verify_fail} mismatches", "warn")
            self._pt_log(f"  ⏱  Time   : {ts_str}", "ok")
            self._pt_log(f"  💾  Dest   : {actual_dst}", "ok")
            self._pt_log("━"*52, "head")
            self._pt_timer_running = False
            self.after(0, lambda: self.lbl_pt_speed.config(text="Done!", fg=C["green"]))
            self.after(0, lambda: self.pt_pb.config(value=100))
            self.after(0, lambda: self.lbl_pt_pct.config(text="100%"))

            msg = (f"Transfer Complete!\n\n"
                   f"📁  Folder : '{src_name}'\n"
                   f"✓  Copied : {copied:,} files ({fmt_size(copied_size)})\n"
                   f"⏱  Time   : {ts_str}\n"
                   f"💾  Dest   : {actual_dst}")
            if errors:
                msg += f"\n✗  Errors : {errors}"
            if verify_fail:
                msg += f"\n⚠  Verify : {verify_fail} mismatches"
            self.after(0, lambda m=msg: messagebox.showinfo("Transfer Complete!", m))

        except Exception as e:
            self._pt_log(f"  ✗  Unexpected error: {e}", "err")
        finally:
            self._pt_timer_running = False
            self._pt_speed_running = False
            self.after(0, lambda: self.btn_pt_start.config(state="normal"))
            self.after(0, lambda: self.btn_pt_cancel.config(state="disabled"))


if __name__=="__main__":
    App().mainloop()
