"""
DataBridge PRO - Icon Updater
Run this to refresh the desktop icon with the new design.
"""
import os, shutil, subprocess, sys
from pathlib import Path

SCRIPT_DIR  = Path(__file__).parent.resolve()
ICON_SRC    = SCRIPT_DIR / "icon.ico"
INSTALL_DIR = Path(os.environ["LOCALAPPDATA"]) / "DataBridge"
ICON_DST    = INSTALL_DIR / "icon.ico"
APP_DST     = INSTALL_DIR / "databridge.py"
DESKTOP_LNK = Path(os.environ["USERPROFILE"]) / "Desktop" / "DataBridge PRO.lnk"

def main():
    print()
    print("  DataBridge PRO - Icon Updater")
    print("  ==============================")
    print()

    if not ICON_SRC.exists():
        print(f"  ERROR: icon.ico not found in {SCRIPT_DIR}")
        input("  Press Enter to exit...")
        return

    # Copy new icon
    INSTALL_DIR.mkdir(parents=True, exist_ok=True)
    shutil.copy2(ICON_SRC, ICON_DST)
    print(f"  OK: New icon copied to {ICON_DST}")

    # Find pythonw
    py = sys.executable
    pythonw = Path(py).parent / "pythonw.exe"
    if not pythonw.exists(): pythonw = Path(py)

    # Recreate desktop shortcut with new icon
    vbs = f"""Set oWS = WScript.CreateObject("WScript.Shell")
Set oLink = oWS.CreateShortcut("{DESKTOP_LNK}")
oLink.TargetPath = "{pythonw}"
oLink.Arguments = """{APP_DST}"""
oLink.WorkingDirectory = "{INSTALL_DIR}"
oLink.Description = "DataBridge PRO"
oLink.IconLocation = "{ICON_DST},0"
oLink.Save
"""
    tmp = INSTALL_DIR / "_upd_icon.vbs"
    tmp.write_text(vbs, encoding="utf-8")
    subprocess.run(["cscript.exe", "//Nologo", str(tmp)],
                   capture_output=True)
    tmp.unlink(missing_ok=True)

    # Clear Windows icon cache
    subprocess.run(
        ["ie4uinit.exe", "-show"],
        capture_output=True)

    if DESKTOP_LNK.exists():
        print("  OK: Desktop shortcut updated with new icon!")
    else:
        print("  WARN: Shortcut not found — run install.py first")

    print()
    print("  Done! Right-click Desktop → Refresh to see the new icon.")
    print()
    input("  Press Enter to close...")

if __name__ == "__main__":
    main()
