@echo off
title DataBridge PRO - Icon Fix
color 0A
echo.
echo  =============================================
echo    DataBridge PRO - Icon Cache Fix
echo  =============================================
echo.

:: ── Step 1: Copy new icon ────────────────────────────────────
echo  [1/5] Copying new icon...
if not exist "%localappdata%\DataBridge\" mkdir "%localappdata%\DataBridge\"
copy /y "%~dp0icon.ico" "%localappdata%\DataBridge\icon.ico" >nul 2>&1
echo        Done.

:: ── Step 2: Delete ALL old shortcuts ─────────────────────────
echo  [2/5] Removing old shortcuts...
del /f /q "%USERPROFILE%\Desktop\DataBridge PRO.lnk" >nul 2>&1
del /f /q "%USERPROFILE%\Desktop\DataBridge PRO.bat" >nul 2>&1
del /f /q "%USERPROFILE%\Desktop\PhoneToMemo PRO.lnk" >nul 2>&1
echo        Done.

:: ── Step 3: Kill Explorer + clear icon cache ─────────────────
echo  [3/5] Clearing Windows icon cache...
taskkill /f /im explorer.exe >nul 2>&1
timeout /t 1 /nobreak >nul

:: Delete every icon cache file Windows uses
del /f /ah "%localappdata%\IconCache.db" >nul 2>&1
del /f /q  "%localappdata%\IconCache.db" >nul 2>&1

for %%f in ("%localappdata%\Microsoft\Windows\Explorer\iconcache_*.db") do (
    del /f /q "%%f" >nul 2>&1
)
for %%f in ("%localappdata%\Microsoft\Windows\Explorer\thumbcache_*.db") do (
    del /f /q "%%f" >nul 2>&1
)
ie4uinit.exe -ClearIconCache >nul 2>&1
ie4uinit.exe -show >nul 2>&1
echo        Done.

:: ── Step 4: Create fresh shortcut ────────────────────────────
echo  [4/5] Creating new shortcut with updated icon...

set "APP=%localappdata%\DataBridge\databridge.py"
set "ICO=%localappdata%\DataBridge\icon.ico"
set "LNK=%USERPROFILE%\Desktop\DataBridge PRO.lnk"

:: Find python
set "PYW="
for /f "tokens=*" %%i in ('where pythonw.exe 2^>nul') do (
    if "!PYW!"=="" set "PYW=%%i"
)
if "%PYW%"=="" (
    for /f "tokens=*" %%i in ('where python.exe 2^>nul') do (
        if "%PYW%"=="" set "PYW=%%i"
    )
)
if "%PYW%"=="" set "PYW=python.exe"

:: Write VBS to create shortcut
set "VBS=%temp%\db_mklink_%RANDOM%.vbs"
(
echo Set oWS = WScript.CreateObject^("WScript.Shell"^)
echo Set oLink = oWS.CreateShortcut^("%LNK%"^)
echo oLink.TargetPath = "%PYW%"
echo oLink.Arguments = """%APP%"""
echo oLink.WorkingDirectory = "%localappdata%\DataBridge"
echo oLink.Description = "DataBridge PRO - Data Transfer Tool"
echo oLink.IconLocation = "%ICO%,0"
echo oLink.WindowStyle = 1
echo oLink.Save
) > "%VBS%"
cscript //nologo "%VBS%"
del /f /q "%VBS%" >nul 2>&1
echo        Done.

:: ── Step 5: Restart Explorer ─────────────────────────────────
echo  [5/5] Restarting Windows Explorer...
start "" explorer.exe
timeout /t 2 /nobreak >nul
echo        Done.

echo.
echo  =============================================
echo    ICON UPDATED SUCCESSFULLY!
echo  =============================================
echo.
echo  If the icon still looks old:
echo    1. Right-click the Desktop
echo    2. Click Refresh
echo    3. Wait 5 seconds
echo.
pause
